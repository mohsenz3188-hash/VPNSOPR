package tunnelspec

// Performance presets.
//
// A preset is a single choice that fills every tuning knob of a tunnel —
// buffers, pool sizes, mux windows and (for KCP) the retransmission and FEC
// settings. The same three presets apply to every transport, so the answer to
// "how hard should this tunnel push?" is the same question everywhere.
//
// Upgrade note: a preset is applied once, when a tunnel is created or when the
// operator picks "Change performance preset". The numbers are written into the
// tunnel's config file, and an update replaces only the binary — it never
// rewrites a config. So changing the values here cannot disturb a tunnel that
// already exists: it keeps the numbers on its disk until somebody deliberately
// re-applies a preset. New tunnels get the current values, and a config with no
// preset field at all is left exactly as it is.
const (
	PresetBalance    = "balance"
	PresetTurbo      = "turbo"
	PresetAggressive = "aggressive"
	// PresetThroughput is the odd one out, and deliberately so.
	//
	// Balance, Turbo and Aggressive are all gaming profiles: they differ only in
	// how much headroom they buy, and every one of them spends bandwidth to hold
	// the ping steady — immediate ACKs, a 10 ms tick, and enough parity to repair
	// a lost packet rather than wait a round trip for it to be resent. That is
	// the right trade for a game and the wrong one for a download, and no amount
	// of tuning inside those three fixes it, because the cost is the point.
	//
	// This preset makes the opposite trade on the same transport: batch the ACKs,
	// tick half as often, carry a tenth as much parity, and open the window wide
	// enough that one stream can actually fill a long fat path. It is for the
	// operator who wants the tunnel to move data quickly and is not measuring
	// their ping while it does.
	//
	// It is offered on the plain "udp + kcp + fec" transport only. The other
	// carriers in the KCP family — xdi, spoof, pck — exist to get through a path
	// that blocks the ordinary one, and each pays for that with hand-built
	// packets and a syscall per datagram. Bandwidth is not what they are for, and
	// offering a "maximum bandwidth" profile on them would promise something the
	// carrier underneath cannot deliver. On a TCP-based transport it would be
	// worse still: every knob it changes belongs to the kernel's stack rather
	// than to this process, so choosing it there would change nothing at all.
	PresetThroughput = "throughput"
)

// PresetOption is one preset as the setup and edit menus and the panel offer it.
type PresetOption struct {
	Label string `json:"label"`
	Desc  string `json:"desc"`
	Value string `json:"value"`
	// KCPOnly marks a preset that only applies to the udp+kcp+fec transport,
	// so a panel rendering the full list can hide or disable it elsewhere.
	KCPOnly bool `json:"kcpOnly,omitempty"`
}

// PresetOptions is the ordered list shown in the setup and edit menus.
var PresetOptions = []PresetOption{
	{"Balance", "light on CPU and RAM — best for small or shared VPS", PresetBalance, false},
	{"Turbo", "recommended — the tuned default for Iran to abroad links", PresetTurbo, false},
	{"Aggressive", "maximum gaming headroom, noticeably more CPU — for strong servers", PresetAggressive, false},
	{"Throughput", "maximum bandwidth for udp+kcp+fec — trades steady ping for speed", PresetThroughput, true},
}

// ValidPreset reports whether p names a preset at all. It deliberately does not
// ask which transport is in play: a config that already names a preset must keep
// loading, and the transport check belongs where a choice is being made.
func ValidPreset(p string) bool {
	switch p {
	case PresetBalance, PresetTurbo, PresetAggressive, PresetThroughput:
		return true
	}
	return false
}

// PresetSuitsTransport reports whether a preset can be chosen for a transport.
// Throughput is for the plain udp+kcp+fec transport alone — see the constant for
// why the other KCP carriers are excluded rather than merely discouraged.
func PresetSuitsTransport(preset, transport string) bool {
	if preset != PresetThroughput {
		return true
	}
	return transport == "kcp"
}

// PresetOptionsFor returns the presets offerable for a transport, in menu order.
func PresetOptionsFor(transport string) []PresetOption {
	out := PresetOptions[:0:0]
	for _, o := range PresetOptions {
		if o.KCPOnly && !PresetSuitsTransport(o.Value, transport) {
			continue
		}
		out = append(out, o)
	}
	return out
}

// presetLabel returns the display name of a preset value.
func presetLabel(value string) string {
	for _, o := range PresetOptions {
		if o.Value == value {
			return o.Label
		}
	}
	if value == "" {
		return "Custom"
	}
	return value
}

// ApplyPreset fills every tuning field of a spec from the named preset. It is
// the single place where the numbers behind Balance/Turbo/Aggressive live, so
// the CLI, the edit screen and the benchmark all agree on what a preset means.
func ApplyPreset(s *Spec, preset string) {
	if !ValidPreset(preset) {
		preset = PresetTurbo
	}
	s.Preset = preset
	s.LogLevel = "info"
	s.Nodelay = true // disable Nagle — lowest latency on every transport

	switch preset {
	case PresetBalance:
		s.KeepAlive = 75
		s.Heartbeat = 40
		s.ChannelSize = 2048
		s.ConnectionPool = 4
		// A steady pool keeps idle CPU low, which is the whole point of Balance.
		s.AggressivePool = false
		// Sizes the datagram socket only; TCP is auto-tuned by the kernel.
		s.SoRcvBuf = 4 * 1024 * 1024
		s.SoSndBuf = 4 * 1024 * 1024
		s.MuxCon = 4
		s.MuxVersion = 2
		s.MuxFrameSize = 32768
		// 256 KB per stream ≈ 20 Mbit/s for one connection at 100 ms — modest
		// on purpose, but four times what 64 KB allowed. Worst-case memory is
		// MuxCon × MuxRecvBuffer = 4 × 4 MB.
		s.MuxRecvBuffer = 4 * 1024 * 1024
		s.MuxStreamBuffer = 256 * 1024

	case PresetTurbo:
		s.KeepAlive = 75
		s.Heartbeat = 40
		s.ChannelSize = 4096
		s.ConnectionPool = 8 // enough warm connections without constant churn
		// AggressivePool stays OFF here: it keeps the pool topped up in a tight
		// loop and noticeably raises idle CPU. A normal pool is plenty.
		s.AggressivePool = false
		// Sizes the datagram socket only; TCP is auto-tuned by the kernel.
		s.SoRcvBuf = 8 * 1024 * 1024
		s.SoSndBuf = 8 * 1024 * 1024
		s.MuxCon = 8
		s.MuxVersion = 2
		s.MuxFrameSize = 32768
		// 2 MB per stream ≈ 160 Mbit/s for a single connection at 100 ms RTT.
		// This is the number that decides how fast one download feels, and the
		// old 64 KB capped it at about 5 Mbit/s on that same path — the mux
		// transports were being throttled by their own flow control long before
		// the link ran out. Worst-case memory is MuxCon × MuxRecvBuffer = 8 × 16 MB.
		s.MuxRecvBuffer = 16 * 1024 * 1024
		s.MuxStreamBuffer = 2 * 1024 * 1024

	case PresetAggressive:
		s.KeepAlive = 60
		s.Heartbeat = 25
		s.ChannelSize = 8192
		s.ConnectionPool = 16
		// Refills the pool in a tight loop: lowest possible connect latency at
		// the cost of real idle CPU. Only worth it on a server with cores spare.
		s.AggressivePool = true
		// Sizes the datagram socket only; TCP is auto-tuned by the kernel. 32 MB
		// so a full window can land in one burst without the kernel dropping the
		// tail of it — on a datagram transport that loss is indistinguishable from
		// the network's, and it costs a retransmit at the busiest moment.
		s.SoRcvBuf = 32 * 1024 * 1024
		s.SoSndBuf = 32 * 1024 * 1024
		s.MuxCon = 16
		s.MuxVersion = 2
		s.MuxFrameSize = 65535
		// 16 MB per stream: at 100 ms round trip that is roughly 1.3 Gbit/s for a
		// single connection, and at 200 ms still ~640 Mbit/s — enough that the
		// flow control is never what limits a transfer on this route. The memory
		// is a ceiling on data actually in flight rather than an allocation, but
		// the worst case is real: MuxCon × MuxRecvBuffer = 16 × 32 MB, so this
		// preset wants a server with RAM to spare — as it says it does.
		s.MuxRecvBuffer = 32 * 1024 * 1024
		s.MuxStreamBuffer = 16 * 1024 * 1024

		// The KCP window deliberately stays where it is. It is the one knob on
		// this preset where "more" is not "better": with congestion control off,
		// the window IS the queue, and a deeper queue is exactly the bufferbloat
		// that shows up as the ping spike a gaming preset exists to prevent.
		// Wanting a bigger one is wanting the Throughput profile, which is what
		// it is for.

	case PresetThroughput:
		s.KeepAlive = 75
		s.Heartbeat = 40
		s.ChannelSize = 8192
		s.ConnectionPool = 16
		// Off on purpose, unlike Aggressive. Topping the pool up in a tight loop
		// buys lower connect latency for a new stream and costs real idle CPU —
		// worth it when every millisecond of a game's first packet counts,
		// pointless for a transfer that runs for minutes once it has started.
		s.AggressivePool = false
		// Sizes the UDP socket the whole tunnel shares. A window this large can
		// have far more in flight than the default socket buffer will hold, and a
		// datagram dropped by a full socket buffer is indistinguishable on the
		// wire from one the network lost — it just triggers a retransmit and
		// halves nothing, because congestion control is off. So it is generous.
		s.SoRcvBuf = 32 * 1024 * 1024
		s.SoSndBuf = 32 * 1024 * 1024
		s.MuxCon = 8
		s.MuxVersion = 2
		s.MuxFrameSize = 65535
		// 32 MB per stream is what makes a single download fast on a long path:
		// it is the flow-control ceiling one connection can have outstanding, so
		// at 200 ms round trip it allows roughly 1.3 Gbit/s for one stream, where
		// Turbo's 2 MB would cap that same stream near 80 Mbit/s. Half as many
		// sessions as Aggressive, each with twice the room — a transfer wants one
		// deep stream far more than it wants sixteen shallow ones. Worst case is
		// MuxCon × MuxRecvBuffer = 8 × 64 MB, the same 512 MB ceiling Aggressive
		// asks for, so this needs a server with RAM but no more than that one.
		s.MuxRecvBuffer = 64 * 1024 * 1024
		s.MuxStreamBuffer = 32 * 1024 * 1024
	}

	ApplyKCPPreset(s, preset)
}

// ApplyKCPPreset fills the KCP-only knobs. They are written to the config only
// for the KCP transport, but filling them unconditionally keeps a later
// transport change (tcp -> kcp) from landing on zero values.
//
// KCP here is the "UDP + KCP + FEC" transport: a low-latency gaming tunnel, not
// a bulk mover. So every preset shares the same latency-first ARQ — NoDelay on,
// a 10 ms tick, fast-retransmit at 2 duplicate ACKs, KCP's own congestion
// window off, and ACKs sent immediately — and every preset carries FEC, because
// on a game path repairing a lost packet from parity beats waiting a whole RTT
// for a retransmit. What the preset changes is only how much headroom it buys:
// the window (which, with congestion control off, is also the bound on how much
// data can queue and inflate ping) and the parity ratio (how much loss it can
// absorb before a stall shows through).
func ApplyKCPPreset(s *Spec, preset string) {
	// MTU stays below the common 1500 path MTU with room for the KCP, FEC and
	// encryption headers, so a KCP packet never fragments in transit.
	//
	// 1250 rather than the 1350 this used to be, because every preset here
	// carries FEC and FEC is what makes a too-large MTU fatal rather than
	// merely wasteful. kcp-go pads every shard in a group out to the largest
	// packet in it, so the parity packets are always full size — where a
	// tunnel without FEC sends whatever the payload happened to be and slips
	// its small packets through a short path, one with FEC offers that path a
	// steady stream of maximum-size packets and loses all of them. The routes
	// this runs on are frequently short of 1500: a PPPoE uplink, a provider
	// that encapsulates, a tunnel somewhere upstream nobody controls.
	//
	// The 100 bytes buys nothing measurable — at these window sizes it is
	// under 8% of the per-packet payload — and it is the difference between a
	// FEC tunnel that works on an unremarkable server and one that stalls with
	// nothing in the log to say why.
	s.KCPMTU = 1250

	// Latency-first ARQ, identical on every preset. This is the "fast mode"
	// KCP was built for: NoDelay skips the delayed-ACK wait, a 10 ms tick (the
	// floor kcp-go allows) flushes retransmits promptly, Resend=2 retransmits a
	// segment after two duplicate ACKs instead of on a timer, NoCongestion
	// takes KCP's own AIMD window out of the path so one loss does not halve the
	// rate, and AckNoDelay returns each ACK at once so the sender learns of a
	// loss a round trip sooner. Together they trade bandwidth-efficiency for the
	// steady, low ping a game needs.
	s.KCPInterval = 10
	s.KCPResend = 2
	s.KCPNoDelay = 1
	s.KCPNoCongestion = 1
	s.KCPAckNoDelay = true

	switch preset {
	case PresetBalance:
		// The lightest gaming profile. With congestion control off the window
		// is the ceiling on in-flight data, so keeping it small is what keeps
		// buffering — and therefore worst-case ping — bounded on a modest link.
		// 512 × 1250 / 100 ms ≈ 51 Mbit/s, ample for game traffic plus light
		// browsing through the same tunnel.
		s.KCPSndWnd = 512
		s.KCPRcvWnd = 512
		// 10:2 repairs up to 2 lost packets in every 12 (~17% loss) for a 20%
		// parity cost — the floor that still makes "+ FEC" mean something on a
		// clean-ish route.
		s.KCPDataShards = 10
		s.KCPParityShards = 2

	case PresetTurbo:
		// The recommended default. Twice the window — ~102 Mbit/s of headroom at
		// 100 ms — for room to also pull a download through the tunnel without
		// starving the game packets, still small enough to keep queueing low.
		s.KCPSndWnd = 1024
		s.KCPRcvWnd = 1024
		// 10:3 (~33% loss tolerated, 30% overhead): the middle of the loss the
		// tuned Iran-to-abroad routes this preset targets actually see.
		s.KCPDataShards = 10
		s.KCPParityShards = 3

	case PresetAggressive:
		// The strongest profile, for a bad route on a server with headroom.
		// 2048 × 1250 / 100 ms ≈ 205 Mbit/s — larger, but deliberately far below
		// the old 8192: past the bandwidth-delay product the extra window buys a
		// gaming tunnel nothing but bufferbloat.
		s.KCPSndWnd = 2048
		s.KCPRcvWnd = 2048
		// 10:4 (~40% loss tolerated, 40% overhead): the most parity worth
		// spending before a different route is the better answer.
		s.KCPDataShards = 10
		s.KCPParityShards = 4

	case PresetThroughput:
		// Everything here undoes a latency-first default above, and each one is
		// worth a measurable amount of bandwidth.
		//
		// A 20 ms tick instead of 10 halves the number of times a second the
		// session walks its send queue. With a window this large that walk is not
		// free, and on a small VPS the tick is what puts a ceiling on packets per
		// second long before the link does.
		s.KCPInterval = 20
		// Batch the acknowledgements. AckNoDelay returns an ACK the instant a
		// packet lands, which is how a game learns of a loss a round trip sooner
		// — and on a saturated transfer it very nearly doubles the packets on the
		// wire, every one of them competing with the data for the same link.
		s.KCPAckNoDelay = false
		// 4096 × 1198 bytes ≈ 4.9 MB in flight. This is the number that decides
		// the ceiling on a long path: at 200 ms round trip it allows roughly
		// 196 Mbit/s for a single stream, where Aggressive's 2048 caps the same
		// stream near 98. It is also why this is not a gaming preset — with
		// congestion control off, a window that large is a queue that deep, and
		// a queue that deep is bufferbloat under load.
		s.KCPSndWnd = 4096
		s.KCPRcvWnd = 4096
		// 10:1 — about 10% overhead instead of Aggressive's 40%. Parity is a
		// straight tax on bandwidth: every parity packet is a packet of capacity
		// not carrying data. A gaming preset pays it gladly, because repairing a
		// loss from parity beats waiting a round trip for the retransmit. A
		// transfer does not care when a byte arrives, only how many arrive a
		// second, so it keeps just enough parity to absorb ordinary jitter-loss
		// and lets ARQ handle the rest.
		s.KCPDataShards = 10
		s.KCPParityShards = 1
	}
}

// PresetLabel returns the display name of a tunnel's performance preset.
func PresetLabel(name string) string {
	s, err := Load(name)
	if err != nil {
		return ""
	}
	return presetLabel(s.Preset)
}

// PresetValueLabel maps a raw preset config value to its display name
// ("turbo" → "Turbo", "" → "Custom"), for callers that already hold the
// decoded config and should not re-read it from disk.
func PresetValueLabel(value string) string { return presetLabel(value) }
