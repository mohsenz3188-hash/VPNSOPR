package client

import (
	"context"
	"time"

	"github.com/backpack/backpack/internal/utils"

	"github.com/backpack/backpack/config"

	"github.com/backpack/backpack/internal/client/transport"
	"github.com/backpack/backpack/internal/debugserver"
	"github.com/backpack/backpack/internal/tunnel/chain"
	"github.com/backpack/backpack/internal/tunnel/naive"
	"github.com/backpack/backpack/internal/utils/handlers"
	"github.com/backpack/backpack/internal/utils/network"
	"github.com/backpack/backpack/internal/web"

	"github.com/sirupsen/logrus"
)

// Client encapsulates the client configuration and state
type Client struct {
	config *config.ClientConfig
	ctx    context.Context
	cancel context.CancelFunc
	logger *logrus.Logger
}

func NewClient(cfg *config.ClientConfig, parentCtx context.Context) *Client {
	ctx, cancel := context.WithCancel(parentCtx)
	// One process runs one tunnel, so the socket tuning is process-wide.
	network.SetPinTCPBuffers(cfg.SOPinTCP)
	// Off unless this tunnel asked for it; see handlers/zerocopy.go.
	handlers.SetZeroCopy(cfg.ZeroCopy)
	// Loopback unless this tunnel asked otherwise; see web/monitorhttp.go.
	web.SetMonitorBind(cfg.WebBind)
	return &Client{
		config: cfg,
		ctx:    ctx,
		cancel: cancel,
		logger: utils.NewLoggerWithFormat(cfg.LogLevel, cfg.LogFormat),
	}
}

// Start starts the client and begins dialing the tunnel server.
func (c *Client) Start() {
	// Profiling endpoint, off unless explicitly enabled in the config. Bound to
	// loopback: pprof is unauthenticated and its heap dump would expose the
	// tunnel token. Reach it with `ssh -L 6061:127.0.0.1:6061 root@server`.
	// It is tied to this generation's context, and Start does not return until
	// it has let go of the port; see the same block in internal/server.
	if c.config.PPROF {
		pprofStopped := make(chan struct{})
		go func() {
			defer close(pprofStopped)
			c.logger.Info("pprof listening on 127.0.0.1:6061 (loopback only)")
			if err := debugserver.Serve(c.ctx, "127.0.0.1:6061"); err != nil {
				c.logger.Errorf("pprof server stopped: %v", err)
			}
		}()
		defer func() { <-pprofStopped }()
	}

	c.logger.Infof("client with remote address %s started successfully", c.config.RemoteAddr)

	// One rotating endpoint list shared by every transport: the primary
	// address plus any fallbacks, so a filtered IP or blocked port is
	// retried against the next option instead of stalling the tunnel.
	endpoints := network.NewEndpoints(c.config.RemoteAddr, c.config.FallbackAddrs...)
	if endpoints.Len() > 1 {
		c.logger.Infof("%d server endpoints configured (failover enabled)", endpoints.Len())
	}
	// With balancing on, new data connections are spread over every endpoint
	// rather than all following the control channel.
	if c.config.LoadBalance && endpoints.Len() > 1 {
		endpoints.SetSpread(true)
		c.logger.Infof("load balancing enabled across %d endpoints", endpoints.Len())
	}
	// With automatic failover on, a scoring loop measures every endpoint and
	// keeps traffic on the healthiest one — the multi-exit gaming behaviour.
	// It overrides spread (it concentrates on one exit on purpose), so it is
	// checked last and wins when both are set.
	if c.config.HealthFailover && endpoints.Len() > 1 {
		endpoints.EnableHealthSteering(c.ctx, 5*time.Second, func(m string) { c.logger.Info(m) })
		c.logger.Infof("automatic health failover enabled across %d endpoints", endpoints.Len())
	}

	// Built once for every transport that can use it. The configuration was
	// already validated at load time, so a failure here would mean the file
	// changed underneath us; dialling directly is the safe reading, and it is
	// said out loud rather than assumed.
	outbound, err := buildOutbound(c.config)
	if err != nil {
		c.logger.Errorf("ignoring the configured outbound settings and dialling directly: %v", err)
		outbound = nil
	}
	if c.config.Naive.Enabled() || c.config.Xray.Enabled() {
		helper, err := naive.StartWithRetry(c.ctx, c.logger, func() (*naive.Helper, error) {
			if c.config.Xray.Enabled() {
				return naive.StartXrayClient(c.ctx, c.config, c.logger)
			}
			return naive.StartClient(c.ctx, c.config, c.logger)
		})
		if err != nil {
			return
		}
		defer helper.Close()
		proxy, err := network.ParseProxy(helper.ProxyURL())
		if err != nil {
			c.logger.Error("invalid managed transport proxy")
			return
		}
		outbound = &network.Outbound{Proxy: proxy}
	}
	if outbound.IsSet() {
		c.logger.Infof("reaching the tunnel server %s", outbound)
	}

	// One transport, or an ordered chain of them. With no fallbacks configured
	// the chain holds a single candidate and behaves exactly as the switch it
	// replaced: start it, wait for the context. With fallbacks it rotates past
	// a carrier that never comes up. See internal/tunnel/chain.
	ch := chain.New(string(c.config.Transport),
		config.FallbackNames(c.config.FallbackTransports),
		config.Dwell(c.config.FallbackDwell)).
		OnLog(func(m string) { c.logger.Info(m) })
	if !ch.Single() {
		c.logger.Infof("transport fallback chain: %v", ch.Candidates())
	}
	// sweep: the client tries each candidate for a fraction of the dwell so it
	// covers the whole list inside one server dwell, which is what makes the
	// two ends meet without negotiating.
	ch.Run(c.ctx, true, func(ctx context.Context, name string) chain.Attempt {
		r := c.startTransport(ctx, config.TransportType(name), endpoints, outbound)
		if r == nil {
			return chain.Attempt{}
		}
		return chain.Attempt{Settled: r.Running}
	})

	c.logger.Info("all workers stopped successfully")

	// suppress other logs
	c.logger.SetLevel(logrus.FatalLevel)
}
func (c *Client) Stop() {
	if c.cancel != nil {
		c.cancel()
	}
}

// buildOutbound turns the client's configuration into the description the
// dialer wants. A configuration with none of it set yields nil, which is the
// ordinary "dial directly" case and costs nothing to carry.
func buildOutbound(cfg *config.ClientConfig) (*network.Outbound, error) {
	proxy, err := network.ParseProxy(cfg.Proxy)
	if err != nil {
		return nil, err
	}
	out := &network.Outbound{
		Proxy:     proxy,
		LocalAddr: cfg.LocalAddr,
		Interface: cfg.Interface,
		Mark:      cfg.SOMark,
	}
	if !out.IsSet() {
		return nil, nil
	}
	if err := out.Validate(); err != nil {
		return nil, err
	}
	return out, nil
}

// runner is what a started transport gives the chain back: a way to ask
// whether the control channel is up. Every transport already answers it — see
// internal/client/transport/status.go.
type runner interface{ Running() bool }

// startTransport launches one transport under ctx and returns it. Cancelling
// ctx tears it down; nothing else here reaches for c.ctx, so a chain can run
// several of these one after another in the same process.
func (c *Client) startTransport(ctx context.Context, tr config.TransportType, endpoints *network.Endpoints, outbound *network.Outbound) runner {
	// Steering asks the tunnel port itself where it can, not only ping; which
	// way depends on the transport running now. See SetReachProbe.
	if tcpPortTransport(tr) {
		endpoints.SetReachProbe(network.TCPReach(2 * time.Second))
	} else {
		endpoints.SetReachProbe(nil)
	}
	switch tr {
	case config.TCP, config.STEALTH:
		tcpConfig := &transport.TcpConfig{
			RemoteAddr:     c.config.RemoteAddr,
			Endpoints:      endpoints,
			Nodelay:        c.config.Nodelay,
			KeepAlive:      time.Duration(c.config.Keepalive) * time.Second,
			RetryInterval:  time.Duration(c.config.RetryInterval) * time.Second,
			DialTimeOut:    time.Duration(c.config.DialTimeout) * time.Second,
			ConnPoolSize:   c.config.ConnectionPool,
			Token:          c.config.Token,
			Sniffer:        c.config.Sniffer,
			WebPort:        c.config.WebPort,
			SnifferLog:     c.config.SnifferLog,
			AggressivePool: c.config.AggressivePool,
			MSS:            c.config.MSS,
			SO_RCVBUF:      c.config.SO_RCVBUF,
			SO_SNDBUF:      c.config.SO_SNDBUF,
			Outbound:       outbound,
			// Stealth is the TCP transport with a Noise record layer over every
			// tunnel connection; everything else about it is identical.
			Stealth:       tr == config.STEALTH,
			ManagedHelper: c.config.Naive.Enabled() || c.config.Xray.Enabled(),
		}
		tcpClient := transport.NewTCPClient(ctx, tcpConfig, c.logger)
		go tcpClient.Start()
		return tcpClient

	case config.TCPMUX:
		tcpMuxConfig := &transport.TcpMuxConfig{
			RemoteAddr:       c.config.RemoteAddr,
			Endpoints:        endpoints,
			Nodelay:          c.config.Nodelay,
			KeepAlive:        time.Duration(c.config.Keepalive) * time.Second,
			RetryInterval:    time.Duration(c.config.RetryInterval) * time.Second,
			DialTimeOut:      time.Duration(c.config.DialTimeout) * time.Second,
			ConnPoolSize:     c.config.ConnectionPool,
			Token:            c.config.Token,
			MuxVersion:       c.config.MuxVersion,
			MaxFrameSize:     c.config.MaxFrameSize,
			MaxReceiveBuffer: c.config.MaxReceiveBuffer,
			MaxStreamBuffer:  c.config.MaxStreamBuffer,
			Sniffer:          c.config.Sniffer,
			WebPort:          c.config.WebPort,
			SnifferLog:       c.config.SnifferLog,
			AggressivePool:   c.config.AggressivePool,
			MSS:              c.config.MSS,
			SO_RCVBUF:        c.config.SO_RCVBUF,
			SO_SNDBUF:        c.config.SO_SNDBUF,
			Outbound:         outbound,
		}
		tcpMuxClient := transport.NewMuxClient(ctx, tcpMuxConfig, c.logger)
		go tcpMuxClient.Start()
		return tcpMuxClient

	case config.KCP, config.XDI, config.PCK:
		kcp := c.config.KCPConfig.WithDefaults()
		useICMP := tr == config.XDI
		kcpConfig := &transport.KcpConfig{
			RemoteAddr:       c.config.RemoteAddr,
			Endpoints:        endpoints,
			KeepAlive:        time.Duration(c.config.Keepalive) * time.Second,
			RetryInterval:    time.Duration(c.config.RetryInterval) * time.Second,
			DialTimeOut:      time.Duration(c.config.DialTimeout) * time.Second,
			ConnPoolSize:     c.config.ConnectionPool,
			Token:            c.config.Token,
			MuxVersion:       c.config.MuxVersion,
			MaxFrameSize:     c.config.MaxFrameSize,
			MaxReceiveBuffer: c.config.MaxReceiveBuffer,
			MaxStreamBuffer:  c.config.MaxStreamBuffer,
			Sniffer:          c.config.Sniffer,
			WebPort:          c.config.WebPort,
			SnifferLog:       c.config.SnifferLog,
			AggressivePool:   c.config.AggressivePool,
			SO_RCVBUF:        c.config.SO_RCVBUF,
			SO_SNDBUF:        c.config.SO_SNDBUF,
			MTU:              kcp.MTU,
			Interval:         kcp.Interval,
			Resend:           kcp.Resend,
			NoDelay:          kcp.NoDelay,
			NoCongestion:     kcp.NoCongestion,
			SndWnd:           kcp.SndWnd,
			RcvWnd:           kcp.RcvWnd,
			AckNoDelay:       kcp.AckNoDelay,
			DataShards:       kcp.DataShards,
			ParityShards:     kcp.ParityShards,
			UseICMP:          useICMP,
			UsePck:           tr == config.PCK,
			PckInterface:     c.config.PckInterface,
			PckGatewayMAC:    c.config.PckGatewayMAC,
			PckFlags:         c.config.PckFlags,
		}
		kcpClient := transport.NewKcpClient(ctx, kcpConfig, c.logger)
		go kcpClient.Start()
		return kcpClient

	case config.QUIC:
		quicConfig := &transport.QuicConfig{
			RemoteAddr:     c.config.RemoteAddr,
			Endpoints:      endpoints,
			KeepAlive:      time.Duration(c.config.Keepalive) * time.Second,
			RetryInterval:  time.Duration(c.config.RetryInterval) * time.Second,
			DialTimeOut:    time.Duration(c.config.DialTimeout) * time.Second,
			ConnPoolSize:   c.config.ConnectionPool,
			Token:          c.config.Token,
			Sniffer:        c.config.Sniffer,
			WebPort:        c.config.WebPort,
			SnifferLog:     c.config.SnifferLog,
			AggressivePool: c.config.AggressivePool,
			SO_RCVBUF:      c.config.SO_RCVBUF,
			SO_SNDBUF:      c.config.SO_SNDBUF,
		}
		quicClient := transport.NewQuicClient(ctx, quicConfig, c.logger)
		go quicClient.Start()
		return quicClient

	case config.WS, config.WSS:
		WsConfig := &transport.WsConfig{
			RemoteAddr:     c.config.RemoteAddr,
			Endpoints:      endpoints,
			Nodelay:        c.config.Nodelay,
			KeepAlive:      time.Duration(c.config.Keepalive) * time.Second,
			RetryInterval:  time.Duration(c.config.RetryInterval) * time.Second,
			DialTimeOut:    time.Duration(c.config.DialTimeout) * time.Second,
			ConnPoolSize:   c.config.ConnectionPool,
			Token:          c.config.Token,
			Sniffer:        c.config.Sniffer,
			WebPort:        c.config.WebPort,
			SnifferLog:     c.config.SnifferLog,
			Mode:           tr,
			SimpleAuth:     c.config.SimpleAuth,
			AggressivePool: c.config.AggressivePool,
			EdgeIP:         c.config.EdgeIP,
			MSS:            c.config.MSS,
			Outbound:       outbound,
		}
		WsClient := transport.NewWSClient(ctx, WsConfig, c.logger)
		go WsClient.Start()
		return WsClient

	case config.WSMUX, config.WSSMUX:
		wsMuxConfig := &transport.WsMuxConfig{
			RemoteAddr:       c.config.RemoteAddr,
			Endpoints:        endpoints,
			Nodelay:          c.config.Nodelay,
			KeepAlive:        time.Duration(c.config.Keepalive) * time.Second,
			RetryInterval:    time.Duration(c.config.RetryInterval) * time.Second,
			DialTimeOut:      time.Duration(c.config.DialTimeout) * time.Second,
			ConnPoolSize:     c.config.ConnectionPool,
			Token:            c.config.Token,
			MuxVersion:       c.config.MuxVersion,
			MaxFrameSize:     c.config.MaxFrameSize,
			MaxReceiveBuffer: c.config.MaxReceiveBuffer,
			MaxStreamBuffer:  c.config.MaxStreamBuffer,
			Sniffer:          c.config.Sniffer,
			WebPort:          c.config.WebPort,
			SnifferLog:       c.config.SnifferLog,
			Mode:             tr,
			SimpleAuth:       c.config.SimpleAuth,
			AggressivePool:   c.config.AggressivePool,
			EdgeIP:           c.config.EdgeIP,
			MSS:              c.config.MSS,
			Outbound:         outbound,
		}
		wsMuxClient := transport.NewWSMuxClient(ctx, wsMuxConfig, c.logger)
		go wsMuxClient.Start()
		return wsMuxClient

	case config.UDP:
		udpConfig := &transport.UdpConfig{
			RemoteAddr:     c.config.RemoteAddr,
			Endpoints:      endpoints,
			RetryInterval:  time.Duration(c.config.RetryInterval) * time.Second,
			DialTimeOut:    time.Duration(c.config.DialTimeout) * time.Second,
			ConnPoolSize:   c.config.ConnectionPool,
			Token:          c.config.Token,
			Sniffer:        c.config.Sniffer,
			WebPort:        c.config.WebPort,
			SnifferLog:     c.config.SnifferLog,
			AggressivePool: c.config.AggressivePool,
			SO_RCVBUF:      c.config.SO_RCVBUF,
			SO_SNDBUF:      c.config.SO_SNDBUF,
		}
		udpClient := transport.NewUDPClient(ctx, udpConfig, c.logger)
		go udpClient.Start()
		return udpClient

	default:
		c.logger.Fatal("invalid transport type: ", tr)
		return nil
	}
}

// tcpPortTransport reports whether a transport's tunnel port is TCP, so a
// connection to it says whether it answers.
func tcpPortTransport(tr config.TransportType) bool {
	switch tr {
	case config.TCP, config.TCPMUX, config.WS, config.WSS, config.WSMUX, config.WSSMUX, config.STEALTH:
		return true
	}
	return false
}
