package transport

import (
	"context"
	"net"
	"sync"
	"time"

	"github.com/gorilla/websocket"
)

// enableKeepAlive turns on TCP keepalive on a control connection so a peer that
// dies without closing — a hard kill, or a path that blackholes under load —
// eventually surfaces as a read error instead of a connection that hangs open
// forever. A no-op for anything that is not a TCP connection.
func enableKeepAlive(conn net.Conn, period time.Duration) {
	tcp, ok := conn.(*net.TCPConn)
	if !ok {
		return
	}
	_ = tcp.SetKeepAlive(true)
	_ = tcp.SetKeepAlivePeriod(period)
}

// The control channel is written by the handshake goroutine and read by the
// accept loop, the heartbeat loop and the restart path — all at the same time.
// Left as a plain field it is a data race: Go gives no guarantee about what a
// concurrent reader observes, so the accept loop can see a stale nil and reject
// connections that should have been let through, or a half-published pointer.
//
// These holders make every access explicit and synchronised. They are cheap:
// the lock is held only long enough to copy an interface value, never across a
// network call.

// sameHost reports whether two addresses share a host, ignoring the port.
//
// It compares the parsed IPs rather than their strings, so the same address
// written two ways — an IPv6 peer seen as "::1" and "0:0:0:0:0:0:0:1", or an
// IPv4-mapped IPv6 address — is recognised as one host. A nil address never
// matches anything.
func sameHost(a, b net.Addr) bool {
	if a == nil || b == nil {
		return false
	}
	ha, _, err := net.SplitHostPort(a.String())
	if err != nil {
		return false
	}
	hb, _, err := net.SplitHostPort(b.String())
	if err != nil {
		return false
	}
	ipa, ipb := net.ParseIP(ha), net.ParseIP(hb)
	if ipa == nil || ipb == nil {
		return ha == hb // not IPs (a hostname): fall back to a literal match
	}
	return ipa.Equal(ipb)
}

// netControl holds the control channel for the transports that use a plain
// network connection (tcp, tcpmux, udp, kcp).
type netControl struct {
	mu   sync.RWMutex
	conn net.Conn
}

// Get returns the current control connection, or nil when none is established.
func (c *netControl) Get() net.Conn {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return c.conn
}

// Set publishes a newly established control connection.
func (c *netControl) Set(conn net.Conn) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.conn = conn
}

// Clear forgets the control connection without closing it, used on restart
// where the caller has already dealt with the old one.
func (c *netControl) Clear() {
	c.Set(nil)
}

// IsSet reports whether a control channel is currently established.
func (c *netControl) IsSet() bool {
	return c.Get() != nil
}

// Close closes the control connection if there is one. Safe to call when there
// is not.
func (c *netControl) Close() {
	if conn := c.Get(); conn != nil {
		conn.Close()
	}
}

// RemoteAddr returns the peer address of the control channel, or nil when no
// control channel is established.
func (c *netControl) RemoteAddr() net.Addr {
	if conn := c.Get(); conn != nil {
		return conn.RemoteAddr()
	}
	return nil
}

// wsControl is the same holder for the websocket transports, which work with a
// websocket connection rather than a net.Conn.
type wsControl struct {
	mu   sync.RWMutex
	conn *websocket.Conn
}

func (c *wsControl) Get() *websocket.Conn {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return c.conn
}

func (c *wsControl) Set(conn *websocket.Conn) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.conn = conn
}

func (c *wsControl) Clear() { c.Set(nil) }

func (c *wsControl) IsSet() bool { return c.Get() != nil }

func (c *wsControl) Close() {
	if conn := c.Get(); conn != nil {
		conn.Close()
	}
}

// runState holds the context of the run a transport is currently on.
//
// Restart cancels the old one, builds a new pair and installs it — and then
// starts the next run in a fresh goroutine, which reads the field back to seed
// its generation. Those two are not ordered against each other: the mutex that
// serialises Restart against Restart is released before the new run has read
// anything, so a second restart can be writing the field while the first one's
// Start is still reading it. That is the race the CI detector reported against
// the KCP transport, and every other transport in this package has the same
// pair of fields written the same way.
//
// It is behind a lock for exactly the reason netControl above is: one value
// replaced by one goroutine while several others are looking at it.
type runState struct {
	mu     sync.RWMutex
	ctx    context.Context
	cancel context.CancelFunc
}

// set installs the context of a new run, replacing whatever was there.
func (r *runState) set(ctx context.Context, cancel context.CancelFunc) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.ctx, r.cancel = ctx, cancel
}

// context returns the current run's context. Callers seed a generation from it
// once and then use the copy, so a later restart cannot move the context out
// from under a goroutine mid-run.
func (r *runState) context() context.Context {
	r.mu.RLock()
	defer r.mu.RUnlock()
	return r.ctx
}

// stop cancels the current run if there is one.
func (r *runState) stop() {
	r.mu.RLock()
	cancel := r.cancel
	r.mu.RUnlock()
	if cancel != nil {
		cancel()
	}
}

// tunnelStatus is the one-line state a transport publishes for the panel.
//
// It has two writers that genuinely overlap: Restart clears it, and the run it
// is replacing sets it as that run starts and again when its control channel
// comes up. Restart cancels the old run and then sleeps two seconds before
// clearing, which is ample time for the cancelled run to finish its handshake
// and write "Connected" — so the two collide on a plain string field. Nothing
// reads it unless the sniffer is on, which is why it has gone unnoticed; a
// write against a write is a race whether or not anybody is reading.
type tunnelStatus struct {
	mu sync.RWMutex
	s  string
}

func (t *tunnelStatus) set(v string) {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.s = v
}

func (t *tunnelStatus) get() string {
	t.mu.RLock()
	defer t.mu.RUnlock()
	return t.s
}

// farewell is how a datagram transport's listener knows the client has been
// told the server is going.
//
// Over TCP the goodbye is free: the socket closes and the client reads a FIN.
// Over KCP there is no connection for the kernel to close — the listener is one
// unconnected UDP socket — so the only goodbye the client can hear is the
// SG_Closed the channel handler writes. That write only queues a segment, and
// the listener closing the socket in the same instant is what used to drop it.
// A client whose server had only restarted then sat on a dead session until its
// control deadline ran out: a minute and fifty-three seconds, measured, with the
// default keepalive.
//
// The listener waits for this before it lets go of the socket, bounded, so a
// channel handler that is stuck cannot hold a restart hostage.
type farewell struct {
	once sync.Once
	done chan struct{}
}

func newFarewell() *farewell { return &farewell{done: make(chan struct{})} }

// said marks the goodbye as sent, or as never going to be. Safe to call more
// than once and from any exit path.
func (f *farewell) said() { f.once.Do(func() { close(f.done) }) }

// wait blocks until said, or for at most d.
func (f *farewell) wait(d time.Duration) {
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-f.done:
	case <-t.C:
	}
}

// farewellWait bounds how long a listener holds its socket for the goodbye.
// The goodbye itself costs one write and kcpFarewellFlush; the bound is for
// the handler that never gets there.
const farewellWait = time.Second

// livenessBeat is how often the control channel carries a heartbeat: the
// configured interval, but never longer than maxLivenessBeat.
//
// The heartbeat was only ever a keepalive, and forty seconds is plenty for
// that. It is also the only thing a client over KCP or QUIC can hear from a
// server that has died — there is no kernel on the far side to send a reset —
// and a client can only conclude "dead" after a few missed beats. At forty
// seconds that was the client's whole 112-second fallback; at ten, a client
// that has learned the rhythm (see beatClock on the client side) gives up after
// thirty.
//
// A byte every ten seconds is nothing on any path this runs over, and a client
// too old to learn the rhythm is not affected at all: it waits exactly as long
// as it always did, for beats that now arrive more often.
func livenessBeat(configured time.Duration) time.Duration {
	if configured <= 0 || configured > maxLivenessBeat {
		return maxLivenessBeat
	}
	return configured
}

// maxLivenessBeat is the longest the control channel goes without a heartbeat.
const maxLivenessBeat = 10 * time.Second

// livenessWarmup is the spacing of the first few heartbeats on a new control
// channel, before it settles to livenessBeat.
//
// A client trusts the rhythm only after it has seen three gaps (beatClock).
// At ten seconds a beat that took half a minute, and until then it could only
// wait its long fallback — made for servers older than this one, whose beat
// could be forty seconds or more. So a server that crashed in the first half
// minute of a connection cost the client 115 seconds, measured on KCP, pck and
// xdi alike. The warm-up doubles from a tenth of a second up to the steady
// beat, which gives the client its three gaps within 1.5 seconds of the
// channel opening; a crash from then on is noticed after fifteen seconds (the
// client's floor), then thirty once the steady beat is learnt. Seven extra
// bytes per channel.
//
// It changes nothing for an older client, which only ever resets its deadline
// on a heartbeat, and an older server simply never sends them, which leaves a
// new client exactly as patient as it was.
var livenessWarmup = []time.Duration{
	100 * time.Millisecond, 200 * time.Millisecond, 400 * time.Millisecond, 800 * time.Millisecond,
	1600 * time.Millisecond, 3200 * time.Millisecond, 6400 * time.Millisecond,
}

// livenessTicker delivers the heartbeat schedule on C: livenessWarmup, then
// every livenessBeat. It stands in for the time.Ticker the control loops used.
type livenessTicker struct {
	C    <-chan time.Time
	stop chan struct{}
	once sync.Once
}

func newLivenessTicker(configured time.Duration) *livenessTicker {
	steady := livenessBeat(configured)
	c := make(chan time.Time, 1)
	t := &livenessTicker{C: c, stop: make(chan struct{})}
	go t.run(c, steady)
	return t
}

func (t *livenessTicker) run(c chan<- time.Time, steady time.Duration) {
	timer := time.NewTimer(livenessGap(0, steady))
	defer timer.Stop()
	for i := 1; ; i++ {
		select {
		case <-t.stop:
			return
		case now := <-timer.C:
			// Like a time.Ticker: a beat the loop has not taken yet is not
			// queued twice.
			select {
			case c <- now:
			default:
			}
			timer.Reset(livenessGap(i, steady))
		}
	}
}

// livenessGap is the wait before heartbeat i (from zero) of a channel whose
// steady beat is steady. A heartbeat set shorter than the warm-up keeps its
// own pace throughout.
func livenessGap(i int, steady time.Duration) time.Duration {
	if i < len(livenessWarmup) {
		return min(livenessWarmup[i], steady)
	}
	return steady
}

// Stop ends the schedule. Safe to call more than once.
func (t *livenessTicker) Stop() { t.once.Do(func() { close(t.stop) }) }
