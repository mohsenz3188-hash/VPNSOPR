<p align="center">
  <img src="internal/webui/panel/assets/vpn-sopr-reference.jpg" alt="VPN SOPR cyber shield" width="45%">
</p>

<h1 align="center">VPN SOPR</h1>

<p align="center">
  <b>Cyber-blue tunnel management · Powered by BackPack</b>
</p>

VPN SOPR is a rebranded derivative of the
[BackPack](https://github.com/AminMGMT/BackPack) Go tunnel engine. It preserves
the original tunnel functionality, configuration files, API and service names,
while changing the web panel, sign-in screens, PWA icons and terminal banner.
The default theme is dark navy with electric-blue accents, based on the
supplied artwork. No live VPN server or credentials are included.

To build this customized source on Linux with **Go 1.26.9 or later**:

```bash
go build -o vpn-sopr .
sudo ./vpn-sopr
```

The existing BackPack installer still downloads upstream releases; it will not
install this customized build. For deployments using systemd and existing
BackPack setup links, keep the binary and service names as `backpack` to avoid
breaking compatibility. Follow the original setup guides below for Iran and
kharej tunnel configuration.

This project retains the original [AGPL-3.0 license](LICENSE) and attribution:
Based on BackPack by Amin Mohammadi (AminMGMT).

### One-command VPS installation from your own GitHub repository

Publish **this customized source** to `mohsenz3188-hash/VPNSOPR` on GitHub.
Then use this single command on a supported Linux VPS:

```bash
curl -fsSL https://raw.githubusercontent.com/mohsenz3188-hash/VPNSOPR/main/install-vpn-sopr.sh | sudo bash -s -- --repo mohsenz3188-hash/VPNSOPR
```

The installer downloads **your own branded repository**, verifies the pinned Go
compiler, builds the engine and installs both `vpn-sopr` and the compatible
`backpack` command. With a terminal attached it opens the Setup menu. It does
not download the unbranded BackPack release, configure a tunnel without your
input, expose ports, install Xray/3x-ui/WireGuard or create VPN credentials.

Supported installation targets: Linux VPS with systemd, `apt`/`dnf`/`pacman`,
and `x86_64` or `aarch64` CPU. Ubuntu, Debian, Rocky/AlmaLinux and compatible
distributions are typical. Android, Windows and macOS are **client platforms**
for the backend service, not installation targets for this Linux server engine.
BackPack's reverse/direct tunnels can forward TCP/UDP to independently managed
Xray, 3x-ui, WireGuard or other compatible services.

On a server with an existing BackPack installation, the command stops instead
of overwriting it. Review the maintenance plan and backups first; only use
`--replace` if you explicitly intend to replace that executable. Running
services are never restarted by this script. Use `--no-menu` for automation,
`--dry-run` for a read-only compatibility check, or `--source-dir /path` for
a local/offline source checkout. See `bash install-vpn-sopr.sh --help`.

**Fork warning:** the built-in `Update` menu still targets upstream BackPack
and can replace the customized branding. For now, update by rebuilding this
fork after review, not by using the upstream updater.

---

## Original BackPack documentation

<p align="center">
  <a href="https://github.com/AminMGMT/BackPack/releases/latest">
    <img src="https://img.shields.io/github/v/release/AminMGMT/BackPack?logo=github&label=release&color=orange" alt="Latest release">
  </a>
  <a href="go.mod">
    <img src="https://img.shields.io/github/go-mod/go-version/AminMGMT/BackPack?logo=go&label=Go" alt="Go version">
  </a>
  <a href="LICENSE">
    <img src="https://img.shields.io/github/license/AminMGMT/BackPack?color=orange" alt="License">
  </a>
  <a href="https://github.com/AminMGMT/BackPack/stargazers">
    <img src="https://img.shields.io/github/stars/AminMGMT/BackPack?style=flat&logo=github&color=orange" alt="GitHub stars">
  </a>
  <a href="https://github.com/AminMGMT/BackPack/releases">
    <img src="https://img.shields.io/github/downloads/AminMGMT/BackPack/total?logo=github&label=downloads&color=orange" alt="Downloads">
  </a>
</p>

<p align="center">
  <a href="tutorial/README.md">Tutorials</a> ·
  <a href="docs/README.md">Documentation</a> ·
  <a href="README_FA.md">فارسی</a> ·
  <a href="https://t.me/BlackProtocols">Telegram</a> ·
  <a href="https://t.me/BlackProtocolsGroup">Community</a>
</p>

---

## What is BackPack?

**BackPack** is a high-performance tunnel engine for connecting **Iran ⇄ abroad (kharej)** servers.

It is written in Go and distributed as a self-contained binary with:

* Interactive CLI
* Web monitoring panel
* Multiple tunnel transports
* Full IP direct tunneling
* Automatic failover and transport fallback
* Health checks and route diagnostics
* Backup, rollback and verified updates
* Telegram monitoring
* Multi-server management

BackPack is designed for routes where connectivity is not something you can simply assume will stay healthy.

Instead of depending on one protocol or one path, it gives you several transport and recovery strategies and lets you measure the route before choosing one.

---

# How it works

## Reverse tunnel

The normal BackPack tunnel is a **reverse tunnel**:

```text
                    INTERNET
                       │
                       │ user traffic
                       ▼
                ┌──────────────┐
                │ IRAN SERVER  │
                │              │
                │ Exposed port │
                └──────┬───────┘
                       │
                       │ BackPack tunnel
                       │
                       ▼
                ┌──────────────┐
                │ KHAREJ SERVER│
                │              │
                │ Real service │
                └──────────────┘
```

The direction is important:

```text
KHAREJ ───────────────▶ IRAN
          tunnel
```

The **kharej server dials the Iran server**, while user traffic enters through the Iran server and is forwarded to the service on kharej.

| Server     | Setup          | Role                                                |
| ---------- | -------------- | --------------------------------------------------- |
| **Iran**   | `Setup Iran`   | Listens for the tunnel and exposes forwarded ports  |
| **Kharej** | `Setup Kharej` | Dials Iran and forwards traffic to the real service |

This means:

* The kharej server does **not** need an inbound tunnel port.
* The Iran server needs the tunnel port open.
* The Iran side should be configured first.
* The kharej side needs the Iran address, tunnel port and token generated by the Iran side.

> The **tunnel port** and the **forwarded ports** are different things.
> The tunnel port carries BackPack itself; forwarded ports are the ports your users connect to.

For the complete explanation, see [Before you start](tutorial/before-you-start.md).

---

# Direct tunnel

BackPack also supports a **direct tunnel**, where Iran initiates the connection to kharej.

```text
IRAN ─────────────────────────▶ KHAREJ
             tunnel
```

The current `Setup → Direct` wizard builds BackPack's **full layer-3 tunnel**.

Instead of forwarding individual connections, it creates a private point-to-point network interface between the two machines and carries complete IP packets through it.

```text
┌──────────────┐                  ┌──────────────┐
│ IRAN         │                  │ KHAREJ       │
│              │                  │              │
│ 10.10.0.1    │══════════════════│ 10.10.0.2    │
│              │    BackPack      │              │
└──────────────┘                  └──────────────┘
```

The direct tunnel uses:

* GRE encapsulation
* Noise encryption
* Automatic MTU handling
* Multiple carrier options
* Full IP routing

Set up the Iran server first: `Setup Iran → Direct → carrier`. Its summary, right before **Create This Tunnel**, shows a one-line **setup link** (`backpack://…`) and, under it, one command that installs Backpack on a fresh kharej and builds the tunnel from that link; on a kharej that already runs Backpack choose `Setup Kharej → Direct → the same carrier → Setup Link`, or run `backpack link apply '<link>'`. The token, addresses and tuning come across in the link. For several kharej servers behind one Iran server, repeat it once per kharej — each gets its own link.

See [Direct layer-3 tunnel](docs/l3-direct-tunnel.md).

> The older stream-based `[direct]` engine still exists for existing configurations, but the current wizard builds the layer-3 direct tunnel.

---

# Before you start

There are four things responsible for most first-time setup problems:

### 1. The roles

```text
Users
  │
  ▼
Iran ────────────────▶ Kharej
       BackPack          │
                        ▼
                    Real service
```

### 2. The token

The Iran side generates a random **64-character token**.

Both ends must use the same token.

A mismatch can look like a dead tunnel, especially on encrypted transports where the server may intentionally not respond.

### 3. Port mappings

For example:

```text
443
```

means:

```text
Iran :443
   ↓
Kharej 127.0.0.1:443
```

while:

```text
443=127.0.0.1:2096
```

means:

```text
Iran :443
   ↓
Kharej 127.0.0.1:2096
```

You can also use explicit backend addresses, multiple backends and port ranges.

See [Port mappings](docs/port-mappings.md).

### 4. UDP

Forwarded ports carry **TCP by default**.

UDP forwarding is a separate per-tunnel setting.

Enable it when the service behind the tunnel requires UDP, such as:

* Xray / 3x-ui
* Shadowsocks UDP
* WireGuard
* DNS
* Games

See [Forwarded UDP](docs/forwarded-udp.md).

---

# Quick Start

## 1. Install

On both servers:

```bash
bash <(curl -fsSL https://raw.githubusercontent.com/AminMGMT/BackPack/main/install.sh)
```

Then:

```bash
sudo backpack
```

The installer downloads the release for the server architecture, verifies its published checksum, installs it and opens the CLI.

Supported release architectures currently include:

```text
x86_64  → amd64
aarch64 → arm64
```

If the server cannot reach GitHub, BackPack also supports a completely offline installation.

See [Installation](docs/install.md).

---

## 2. Configure the Iran server

```bash
sudo backpack
```

Then:

```text
1. Setup Iran
→ Reverse
→ Transport
→ Iran IP Or Domain (the detected one is the default)
→ Tunnel Port
→ Forwarded Ports
→ Tunnel Name
→ Security Token (generated — press Enter)
→ Carry UDP As Well As TCP
→ the transport's own questions (certificate for WSS, flags for PCK, …)
→ How Should The Tunnel Be Tuned?
```

The summary before **Create This Tunnel** shows a one-line **Setup Link** (`backpack://…`). Copy it.

For a first deployment, **TCP** is the simplest starting point.

---

## 3. Configure the kharej server

```bash
sudo backpack
```

Then:

```text
2. Setup Kharej
→ Reverse
→ Same transport
→ Setup Link → paste the link → Tunnel Name → Create This Tunnel
```

**Manual** is there too: Iran IP, the same tunnel port, a name, the same token, the same preset.

---

## 4. Check the tunnel

Use:

```text
Manage → Status
```

Then:

```text
Manage → Health Check
```

If you are unsure which transport to use:

```text
Manage → Link Test
```

Link Test measures the route over TCP, including latency, jitter and packet loss, and recommends a suitable transport.

See [Choosing a transport](docs/choosing-a-transport.md).

---

# Which transport should I use?

If you don't know where to start, use this:

| Situation                                         | Start with          |
| ------------------------------------------------- | ------------------- |
| Clean / ordinary route                            | **TCP**             |
| Many short-lived connections                      | **TCP Mux**         |
| TCP is filtered or unstable                       | **TCP + Stealth**   |
| TCP connects but stalls, resets or gets throttled | **TCP + PCK**       |
| You specifically need raw UDP                     | **UDP**             |
| Lossy route / real-time traffic / gaming          | **UDP + KCP + FEC** |
| You want to test QUIC                             | **UDP + QUIC**      |
| HTTP/WebSocket traffic is useful                  | **WS / WS Mux**     |
| HTTPS-style traffic is required                   | **WSS / WSS Mux**   |
| TCP and UDP are filtered but ICMP works           | **xDi (ICMP)**      |
| Inbound access to Iran is unavailable             | **Direct tunnel**   |

The easiest way to choose is:

```text
Kharej
  ↓
Manage → Link Test
  ↓
Measure route
  ↓
Get recommendation
```

See [Choosing a transport](docs/choosing-a-transport.md) and [all transports](docs/transports.md).

---

# Transport overview

BackPack currently provides **twelve reverse-tunnel transports**.

| Transport           | Family       |   Encryption  | PROXY v2 | Requirements        |
| ------------------- | ------------ | :-----------: | :------: | ------------------- |
| TCP                 | TCP          |       —       |     ✓    | —                   |
| TCP Mux             | TCP          |       —       |     ✓    | —                   |
| **TCP + Stealth**   | TCP          |     Noise     |     ✓    | —                   |
| **TCP + PCK**       | TCP          | Token-derived |     ✓    | Linux + root        |
| UDP                 | UDP          |       —       |     —    | UDP open            |
| **UDP + KCP + FEC** | UDP          | Token-derived |     ✓    | UDP open            |
| UDP + QUIC          | UDP          |    TLS 1.3    |     ✓    | UDP open            |
| WS                  | WebSocket    |       —       |     —    | —                   |
| WS Mux              | WebSocket    |       —       |     ✓    | —                   |
| WSS                 | WebSocket    |      TLS      |     —    | Certificate         |
| WSS Mux             | WebSocket    |      TLS      |     ✓    | Certificate         |
| **xDi (ICMP)**      | Experimental | Token-derived |     ✓    | Linux + root + ICMP |

### TCP

Plain reliable TCP.

Low overhead and the simplest starting point on a clean route.

### TCP Mux

Multiplexes multiple logical connections over a small pool of TCP connections.

Useful for services that create many short-lived connections.

### TCP + Stealth

TCP wrapped in a Noise record layer.

The handshake and encrypted stream do not use a TLS ClientHello or a recognizable application protocol header.

Useful when plain TCP is being identified, filtered or killed.

### TCP + PCK

Builds TCP segments without using the kernel's normal TCP connection state.

Useful when normal TCP connects but later stalls, resets or gets throttled.

Requires Linux and root on both ends.

### UDP

Raw UDP transport with minimal overhead.

There is no reliability or ordering layer.

### UDP + KCP + FEC

Reliable, ordered transport over UDP with forward error correction.

Designed for routes where packet loss makes TCP back off too aggressively, and for latency-sensitive traffic.

### UDP + QUIC

QUIC over UDP with TLS 1.3, multiplexing, congestion control and loss recovery.

It is available for testing, but BackPack's route testing does not generally recommend it over KCP for lossy Iran routes.

### WS / WS Mux

WebSocket transport for routes where HTTP traffic is useful or where the tunnel needs to sit behind a CDN.

WS Mux adds multiplexing and PROXY protocol support.

### WSS / WSS Mux

WebSocket over TLS.

WSS can use a real certificate and Chrome-style TLS behavior and can provide a decoy site for probes.

### xDi

Carries the KCP transport inside ICMP echo packets instead of UDP.

Designed for the specific case where TCP and UDP are filtered but ICMP remains available.

It is a last-resort transport rather than the normal starting point.

See the complete [Transport reference](docs/transports.md).

---

# Forwarded UDP

UDP forwarding is independent of the transport carrying the tunnel.

For example:

```text
Iran :443/tcp + :443/udp
        │
        ▼
BackPack
        │
        ▼
Kharej :443/tcp + :443/udp
```

This is useful for:

* Xray / 3x-ui
* WireGuard
* DNS
* Games
* Other services that require UDP

UDP forwarding is **off by default**.

See [Adding UDP to a tunnel](tutorial/udp-forwarding.md).

---

# Reliability

BackPack is built around routes that can change or fail.

## Backup addresses

A tunnel can have multiple server addresses.

BackPack can:

* automatically fail over between addresses
* health-score available addresses
* load-balance across healthy addresses

See [Failover & load balancing](docs/failover-load-balancing.md).

## Transport fallback

A tunnel can also have a fallback chain.

For example:

```toml
transport = "wss"

fallback_transports = [
  "quic",
  "kcp",
  "tcpmux"
]
```

If the active carrier stops getting through, BackPack can move through the configured fallback chain.

See [Transport fallback](docs/transport-fallback.md).

## Self-healing

BackPack includes a watchdog that detects stopped or stalled tunnels and performs recovery.

Services are managed through systemd and survive reboots.

## Automatic rollback

Updates and relevant configuration changes can create restore points and roll back when the tunnel does not return successfully.

---

# Diagnostics

BackPack includes diagnostics directly in the CLI.

### Link Test

Measures:

* latency
* jitter
* packet loss

It also recommends a transport for the measured route.

### Health Check

Checks the server, panel and tunnels and provides a suggested fix when it detects a problem.

### Tunnel Metrics

Provides tunnel-level statistics including traffic, connections and transport-specific metrics such as KCP retransmissions, loss and FEC repairs.

See:

* [Health Check](docs/health-check.md)
* [Tunnel Metrics](docs/tunnel-metrics.md)
* [Performance presets](docs/performance-presets.md)
* [Performance notes](docs/performance-notes.md)

---

# Performance

BackPack provides four performance presets:

* **Balance**
* **Turbo**
* **Aggressive**
* **Throughput**

The first three tune the queues and transport behavior for a full IP tunnel; Throughput is intended for maximizing sustained transfer.

BackPack also includes kernel/network optimization through the CLI.

See [Performance presets](docs/performance-presets.md).

---

# Security

BackPack provides several security mechanisms depending on the transport and deployment mode.

### Encrypted transports

Encrypted tunnel options include:

* TCP + Stealth
* TCP + PCK
* UDP + KCP + FEC
* UDP + QUIC
* WSS
* WSS Mux
* xDi

On plain transports such as TCP, TCP Mux, UDP, WS and WS Mux, the tunnel credential itself is not encrypted by the transport.

### Web panel security

The Web Panel supports:

* Password authentication
* Two-factor authentication
* Recovery codes
* Scoped API tokens
* Authorization records

See [Access control](docs/access-control.md).

### Verified releases

Release archives are verified against the published SHA-256 checksum.

An archive that cannot be verified is refused rather than installed.

See [Updates & rollback](docs/updates.md).

---

# Real client IP

Backends normally see the connection as coming from the tunnel itself.

BackPack can instead send the original client address using **PROXY protocol v2**.

This allows applications and panels behind the tunnel to see the real client IP and keep per-user/device limits working.

Supported transports and limitations are documented in:

[Real client IP / PROXY protocol v2](docs/real-client-ip.md)

---

# Web Panel

BackPack includes a monitoring-focused web dashboard.

It provides:

* CPU usage
* RAM usage
* Disk usage
* Traffic
* Tunnel state
* Real ping
* Logs
* Backup and Telegram settings
* Panel security settings

The panel listens on **port 7777** by default.

```text
Iran server
    │
    └── Web Panel :7777
```

The panel is primarily for monitoring and management around the deployment; tunnel creation and detailed tunnel configuration remain available through the CLI.

It also supports:

* HTTPS
* Custom certificates
* Two-factor authentication
* Recovery codes
* API access control

See:

* [Web Panel](docs/web-panel.md)
* [Web Panel — screen by screen](docs/web-panel-screens.md)

---

# Managed servers

The Web Panel can register remote servers as managed nodes.

Once registered, BackPack can use the panel to build and manage both ends of a tunnel without requiring you to repeat the entire SSH setup manually.

Managed servers can be:

* registered
* edited
* tested
* used to create tunnels
* started
* stopped
* restarted
* removed

See [Managed servers](docs/managed-servers.md).

---

# Telegram monitoring

BackPack can send status and alert messages through Telegram.

The built-in Telegram integration can relay its connection through a tunnel peer, allowing Telegram monitoring from environments where direct Telegram access is unavailable.

It supports:

* periodic status reports
* tunnel status
* resource alerts
* recovery messages
* monitoring events

See:

* [Telegram bot](docs/telegram-bot.md)
* [Alerts](docs/alerts.md)

---

# Backup & Restore

BackPack can create a portable backup containing the important deployment state, including:

* tunnel configurations
* panel settings
* panel password
* Telegram settings
* TLS certificates
* scheduled tasks

Backups are stored as `.tar.gz` archives.

They can also be restored onto another machine.

See [Backup & Restore](docs/backup-restore.md).

---

# Updates

BackPack can update itself from the GitHub release system.

The update process:

1. Detects the available release.
2. Downloads the architecture-specific archive.
3. Verifies the published SHA-256.
4. Installs the release.
5. Uses restore points and recovery logic if the updated tunnel does not return successfully.

Updates can also use a tunnel peer when the server itself cannot reach GitHub.

If neither direct access nor a tunnel path is available, BackPack supports offline updates.

See [Updates & rollback](docs/updates.md).

---

# Offline installation

BackPack does not require the VPS itself to have GitHub access.

Download the release from a machine with internet access and copy it to the server.

For example:

```bash
scp install.sh SHA256SUMS backpack_linux_amd64.tar.gz root@SERVER_IP:/root/

ssh root@SERVER_IP \
  "cd /root && sudo bash install.sh"
```

Or install manually after verifying the checksum:

```bash
sha256sum backpack_linux_amd64.tar.gz

tar xzf backpack_linux_amd64.tar.gz

mkdir -p /etc/backpack /root/BackPack/backups

install -m 0755 backpack /usr/local/bin/backpack

echo /root/BackPack > /etc/backpack/install_path

sudo backpack
```

See [Installation](docs/install.md).

---

# Configuration & operations

For operators who need more than the basic setup, BackPack documents its internal configuration and operational behavior separately.

### CLI

[CLI menu reference](docs/cli-menu.md)

Complete reference for:

* Setup Iran
* Setup Kharej
* Direct setup
* Tunnel management
* Built-in proxy
* Backup & Restore
* Web Panel
* Optimize
* Telegram
* Updates
* Fine Tune
* File locations

### Configuration

[Configuration reference](docs/config-reference.md)

Generated from the configuration declarations and documents every configuration key BackPack reads.

### Server layout

```text
/root/BackPack
/root/BackPack/backups
/etc/backpack
/usr/local/bin/backpack
```

See [Server layout](docs/server-layout.md).

---

# Documentation

BackPack intentionally separates **setup tutorials** from **technical reference**.

## Tutorials

The `tutorial/` directory explains how to actually build a tunnel, step by step, following the CLI wizard.

### Start here

* [Before you start](tutorial/before-you-start.md)

### Reverse transports

* [TCP](tutorial/tcp.md)
* [TCP Mux](tutorial/tcp-mux.md)
* [TCP + Stealth](tutorial/tcp-stealth.md)
* [TCP + PCK](tutorial/tcp-pck.md)
* [UDP](tutorial/udp.md)
* [UDP + KCP + FEC](tutorial/udp-kcp-fec.md)
* [UDP + QUIC](tutorial/udp-quic.md)
* [WS / WS Mux](tutorial/websocket.md)
* [WSS / WSS Mux](tutorial/websocket-tls.md)
* [xDi / ICMP](tutorial/xdi-icmp.md)

### Special deployments

* [Forwarded UDP](tutorial/udp-forwarding.md)
* [Behind X-UI / 3x-ui / Marzban](tutorial/behind-a-panel.md)
* [Direct tunnel](tutorial/direct-tunnel.md)
* [IP Spoofing](tutorial/ip-spoofing.md)

---

## Documentation reference

### Architecture & internals

* [Architecture](docs/architecture.md)
* [Design decisions](docs/design-decisions.md)
* [Performance notes](docs/performance-notes.md)
* [Configuration reference](docs/config-reference.md)

### Transports & networking

* [Transports](docs/transports.md)
* [Choosing a transport](docs/choosing-a-transport.md)
* [Transport fallback](docs/transport-fallback.md)
* [Direct layer-3 tunnel](docs/l3-direct-tunnel.md)
* [Direct stream tunnel](docs/direct-tunnel.md)
* [TCP + PCK](docs/tcp-pck.md)
* [IP Spoofing](docs/ip-spoofing.md)
* [Port mappings](docs/port-mappings.md)
* [Forwarded UDP](docs/forwarded-udp.md)
* [TCP MSS clamp](docs/mss-clamp.md)
* [Filtered / dirty IP](docs/filtered-or-dirty-ip.md)
* [WSS camouflage](docs/camouflage.md)

### Operations

* [Installation](docs/install.md)
* [CLI menu](docs/cli-menu.md)
* [Server layout](docs/server-layout.md)
* [Web Panel](docs/web-panel.md)
* [Web Panel screens](docs/web-panel-screens.md)
* [Managed servers](docs/managed-servers.md)
* [Health Check](docs/health-check.md)
* [Tunnel Metrics](docs/tunnel-metrics.md)
* [Monitor service](docs/monitor-service.md)
* [Troubleshooting](docs/troubleshooting.md)

### Reliability & maintenance

* [Failover & load balancing](docs/failover-load-balancing.md)
* [Transport fallback](docs/transport-fallback.md)
* [Backup & Restore](docs/backup-restore.md)
* [Updates & rollback](docs/updates.md)
* [Performance presets](docs/performance-presets.md)
* [Per-tunnel limits](docs/limits.md)
* [Real client IP](docs/real-client-ip.md)

### Management & security

* [Access control](docs/access-control.md)
* [Telegram bot](docs/telegram-bot.md)
* [Alerts](docs/alerts.md)
* [Log schema](docs/log-schema.md)

### Development

* [Contributing](CONTRIBUTING.md)
* [Releasing](docs/releasing.md)

> Every documentation page includes a Persian summary where applicable.

---

# Screenshots

### CLI

<p align="center">
  <img src="img/cli-Screenshot.png" alt="BackPack CLI">
</p>

### Web Panel

<p align="center">
  <img src="img/web-panel-Screenshot.png" alt="BackPack Web Panel">
</p>

### Tunnel Management

<p align="center">
  <img src="img/cli-manage-Screenshot.png" alt="BackPack tunnel management">
</p>

### Telegram Bot

<p align="center">
  <img src="img/tg-bot-Screenshot.png" alt="BackPack Telegram bot">
</p>

---

# Support & Community

If BackPack is useful to you:

* Star the repository
* Report bugs through GitHub Issues
* Contribute improvements
* Join the Telegram community

### Telegram

* Channel: [@BlackProtocols](https://t.me/BlackProtocols)
* Community: [@BlackProtocolsGroup](https://t.me/BlackProtocolsGroup)

---

# Contributing

Pull requests, bug reports and technical improvements are welcome.

Before contributing:

1. Read [CONTRIBUTING.md](CONTRIBUTING.md).
2. Check the relevant documentation.
3. Keep changes focused.
4. Add or update tests where appropriate.
5. Update documentation when behavior or configuration changes.

For the release process, see [Releasing](docs/releasing.md).

---

# License

Copyright © 2026 Amin Mohammadi (AminMGMT).

BackPack is released under the **GNU Affero General Public License v3.0 (AGPL-3.0)**.

See:

* [LICENSE](LICENSE)
* [NOTICE](NOTICE)
* [TRADEMARK.md](TRADEMARK.md)

You may use, study, modify, redistribute and build a business on BackPack under the terms of the license.

Additional attribution and trademark conditions apply.

### Attribution

Modified versions must keep this line, unaltered, in their README (and in NOTICE):

```text
Based on BackPack by Amin Mohammadi (AminMGMT)
https://github.com/AminMGMT/BackPack
```

### Name & logo

**BackPack**, its name and logo are not licensed as part of the source code.

Forks should use their own name and branding.

It is permitted to truthfully state that a project is based on or compatible with BackPack.

See [TRADEMARK.md](TRADEMARK.md) for the complete terms.
