package cmd

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/x509"
	"encoding/pem"
	"math/big"
	"net"
	"os"
	"path/filepath"
	"reflect"
	"runtime"
	"testing"
	"time"

	"github.com/BurntSushi/toml"

	"github.com/backpack/backpack/config"
	"github.com/sirupsen/logrus"
)

func TestHelperCertificateRenewalValidatesBeforeReload(t *testing.T) {
	if runtime.GOOS != "linux" {
		t.Skip("managed helpers support Linux")
	}
	for _, helper := range []string{"naive", "xhttp"} {
		t.Run(helper, func(t *testing.T) {
			t.Parallel()
			dir := t.TempDir()
			certPath, keyPath := filepath.Join(dir, "cert.pem"), filepath.Join(dir, "key.pem")
			binary, err := os.Executable()
			if err != nil {
				t.Fatal(err)
			}
			makePair := func(serial int64) ([]byte, []byte) {
				t.Helper()
				public, private, err := ed25519.GenerateKey(rand.Reader)
				if err != nil {
					t.Fatal(err)
				}
				cert := &x509.Certificate{SerialNumber: big.NewInt(serial), DNSNames: []string{"localhost"}, NotBefore: time.Now().Add(-time.Hour), NotAfter: time.Now().Add(time.Hour), KeyUsage: x509.KeyUsageDigitalSignature, ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth}}
				if serial == 3 {
					cert.DNSNames = []string{"wrong.example.org"}
				}
				if serial == 4 {
					cert.NotBefore, cert.NotAfter = time.Now().Add(-2*time.Hour), time.Now().Add(-time.Hour)
				}
				der, err := x509.CreateCertificate(rand.Reader, cert, cert, public, private)
				if err != nil {
					t.Fatal(err)
				}
				key, err := x509.MarshalPKCS8PrivateKey(private)
				if err != nil {
					t.Fatal(err)
				}
				return pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der}), pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: key})
			}
			write := func(path string, body []byte) {
				t.Helper()
				if err := os.WriteFile(path, body, 0600); err != nil {
					t.Fatal(err)
				}
			}
			oldCert, oldKey := makePair(1)
			newCert, newKey := makePair(2)
			write(certPath, oldCert)
			write(keyPath, oldKey)
			cfg := config.Config{Server: config.ServerConfig{BindAddr: "127.0.0.1:62001", Transport: config.TCP, Token: "renewal-test", Ports: []string{"62003"}, Naive: config.NaiveServerConfig{Binary: binary, Listen: "127.0.0.1:62002", Username: "u", Password: "p", Certificate: certPath, Key: keyPath}}}
			if helper == "xhttp" {
				cfg.Server.Naive = config.NaiveServerConfig{}
				cfg.Server.Xray = config.XrayServerConfig{Binary: binary, Listen: "127.0.0.1:62002", Mode: "xhttp", UUID: "12345678-1234-4234-8234-123456789abc", ServerName: "localhost", Path: "/renewal", Certificate: certPath, Key: keyPath}
			}
			path := filepath.Join(dir, "tunnel.toml")
			file, err := os.Create(path)
			if err != nil {
				t.Fatal(err)
			}
			if err := toml.NewEncoder(file).Encode(cfg); err != nil {
				file.Close()
				t.Fatal(err)
			}
			file.Close()
			current := loadFixture(t, path)
			if err := validateConfig(current); err != nil {
				t.Fatal(err)
			}
			ctx, cancel := context.WithTimeout(context.Background(), 12*configPollInterval)
			defer cancel()
			type result struct {
				next   *config.Config
				reason wakeReason
			}
			resultC := make(chan result, 1)
			go func() {
				next, reason := awaitConfigChange(ctx, context.Background(), path, current)
				resultC <- result{next, reason}
			}()
			// Let the watcher snapshot the original pair, then exercise several polls.
			time.Sleep(configPollInterval / 2)
			unchanged := func() {
				t.Helper()
				select {
				case got := <-resultC:
					t.Fatalf("unusable or identical certificate restarted the generation: %v", got.reason)
				case <-time.After(configPollInterval + configPollInterval/2):
				}
			}
			write(certPath, oldCert)
			unchanged()
			write(certPath, newCert) // key replacement is not complete yet
			unchanged()
			write(certPath, oldCert) // abandoned renewal restores the still-running pair
			unchanged()
			badCert, badKey := makePair(4)
			write(certPath, badCert)
			write(keyPath, badKey)
			unchanged() // matched but expired replacement must keep the old generation
			if helper == "xhttp" {
				wrongCert, wrongKey := makePair(3)
				write(certPath, wrongCert)
				write(keyPath, wrongKey)
				unchanged() // paired and valid dates, but wrong authenticated hostname
			}
			write(certPath, newCert)
			write(keyPath, newKey)
			select {
			case got := <-resultC:
				if got.reason != wakeConfig || got.next == nil || !reflect.DeepEqual(got.next, current) {
					t.Fatalf("renewal did not reload the same tunnel configuration: %+v", got)
				}
			case <-ctx.Done():
				t.Fatal("valid renewed certificate did not reload without a TOML edit")
			}
		})
	}
}

func TestMain(m *testing.M) {
	// These tests deliberately feed the loader broken files, and the complaints
	// belong in the code's own output, not in the test log.
	logger.SetOutput(os.NewFile(0, os.DevNull))
	logger.SetLevel(logrus.FatalLevel)
	os.Exit(m.Run())
}

func writeConfig(t *testing.T, path, body string) {
	t.Helper()
	if err := os.WriteFile(path, []byte(body), 0o644); err != nil {
		t.Fatalf("write %s: %v", path, err)
	}
	// Size and modification time identify a version of the file, and a
	// filesystem whose timestamps are coarse can hand back the same pair for
	// two writes in the same instant. Stepping the time forward makes the edit
	// unambiguous, which is what an edit minutes later would be anyway.
	future := time.Now().Add(time.Second)
	if err := os.Chtimes(path, future, future); err != nil {
		t.Fatalf("chtimes %s: %v", path, err)
	}
}

func loadFixture(t *testing.T, path string) *config.Config {
	t.Helper()
	cfg, err := loadConfig(path)
	if err != nil {
		t.Fatalf("load %s: %v", path, err)
	}
	applyDefaults(cfg)
	return cfg
}

func serverConfig(port string) string {
	return "\n[server]\nbind_addr = \"0.0.0.0:" + port + "\"\ntransport = \"tcp\"\ntoken = \"a-token\"\nports = [\"8080\"]\n"
}

// A real edit is picked up and handed back.
func TestAwaitConfigChangeReturnsAChangedConfig(t *testing.T) {
	path := filepath.Join(t.TempDir(), "tunnel.toml")
	writeConfig(t, path, serverConfig("3080"))
	current := loadFixture(t, path)

	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()

	go func() {
		time.Sleep(configPollInterval / 2)
		writeConfig(t, path, serverConfig("3090"))
	}()

	next, _ := awaitConfigChange(ctx, context.Background(), path, current)
	if next == nil {
		t.Fatal("an edited configuration was never reported")
	}
	if next.Server.BindAddr != "0.0.0.0:3090" {
		t.Fatalf("reported bind_addr %q, want the edited one", next.Server.BindAddr)
	}
}

// A file that no longer parses must leave the running tunnel alone. A
// half-saved file or a typo turning into an outage would be strictly worse than
// the manual restart this replaces.
func TestAwaitConfigChangeIgnoresAnUnparseableFile(t *testing.T) {
	path := filepath.Join(t.TempDir(), "tunnel.toml")
	writeConfig(t, path, serverConfig("3080"))
	current := loadFixture(t, path)

	ctx, cancel := context.WithTimeout(context.Background(), 3*configPollInterval)
	defer cancel()

	go func() {
		time.Sleep(configPollInterval / 2)
		writeConfig(t, path, "[server\nthis is not toml at all")
	}()

	if next, _ := awaitConfigChange(ctx, context.Background(), path, current); next != nil {
		t.Fatalf("a file that does not parse was applied: %+v", next.Server)
	}
}

// Rewriting the file with the same meaning must not restart the tunnel. Every
// connection it is carrying would be dropped for nothing.
func TestAwaitConfigChangeIgnoresAMeaninglessRewrite(t *testing.T) {
	path := filepath.Join(t.TempDir(), "tunnel.toml")
	body := serverConfig("3080")
	writeConfig(t, path, body)
	current := loadFixture(t, path)

	ctx, cancel := context.WithTimeout(context.Background(), 3*configPollInterval)
	defer cancel()

	go func() {
		time.Sleep(configPollInterval / 2)
		// Same settings, different bytes: a new comment and reordered
		// whitespace, which is what an editor round-trip tends to produce.
		writeConfig(t, path, "# edited by hand\n"+body+"\n")
	}()

	if next, _ := awaitConfigChange(ctx, context.Background(), path, current); next != nil {
		t.Fatal("a rewrite that changed nothing restarted the tunnel")
	}
}

// A change that only differs in a defaulted field must also be ignored: the
// comparison happens after defaults are applied, so writing out the value that
// was already implied is not a change.
func TestAwaitConfigChangeIgnoresAnExplicitDefault(t *testing.T) {
	path := filepath.Join(t.TempDir(), "tunnel.toml")
	writeConfig(t, path, serverConfig("3080"))
	current := loadFixture(t, path)

	ctx, cancel := context.WithTimeout(context.Background(), 3*configPollInterval)
	defer cancel()

	go func() {
		time.Sleep(configPollInterval / 2)
		writeConfig(t, path, serverConfig("3080")+"\nchannel_size = 2048\n")
	}()

	if next, _ := awaitConfigChange(ctx, context.Background(), path, current); next != nil {
		t.Fatalf("writing out an already-default value restarted the tunnel: %+v", next.Server)
	}
}

// Shutting down must win over waiting for an edit, and must be reported as
// "stop" rather than as a reload.
func TestAwaitConfigChangeStopsWithTheContext(t *testing.T) {
	path := filepath.Join(t.TempDir(), "tunnel.toml")
	writeConfig(t, path, serverConfig("3080"))
	current := loadFixture(t, path)

	ctx, cancel := context.WithCancel(context.Background())
	go func() {
		time.Sleep(100 * time.Millisecond)
		cancel()
	}()

	start := time.Now()
	if next, _ := awaitConfigChange(ctx, context.Background(), path, current); next != nil {
		t.Fatal("a cancelled context was reported as a configuration change")
	}
	if elapsed := time.Since(start); elapsed > 5*time.Second {
		t.Fatalf("took %v to notice the shutdown", elapsed)
	}
}

// A file that disappears — mid-rename, say — must not be mistaken for a change,
// and must not stop the watcher looking.
func TestAwaitConfigChangeSurvivesAMissingFile(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "tunnel.toml")
	writeConfig(t, path, serverConfig("3080"))
	current := loadFixture(t, path)

	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()

	go func() {
		time.Sleep(configPollInterval / 2)
		os.Remove(path)
		time.Sleep(configPollInterval)
		writeConfig(t, path, serverConfig("3090"))
	}()

	next, _ := awaitConfigChange(ctx, context.Background(), path, current)
	if next == nil {
		t.Fatal("the watcher gave up when the file briefly went missing")
	}
	if next.Server.BindAddr != "0.0.0.0:3090" {
		t.Fatalf("reported bind_addr %q, want the edited one", next.Server.BindAddr)
	}
}

func TestPortsInUse(t *testing.T) {
	server := &config.Config{}
	server.Server.BindAddr = "0.0.0.0:3080"
	server.Server.Transport = config.TCP
	server.Server.WebPort = 2060
	got := portsInUse(server)
	want := []listenerBinding{
		{network: "tcp", address: "0.0.0.0:3080"},
		{network: "tcp", address: ":2060"},
	}
	if len(got) != 2 || got[0] != want[0] || got[1] != want[1] {
		t.Fatalf("server ports = %v, want %v", got, want)
	}

	client := &config.Config{}
	client.Client.RemoteAddr = "example.com:3080"
	client.Client.WebPort = 2061
	got = portsInUse(client)
	if len(got) != 1 || got[0] != (listenerBinding{network: "tcp", address: ":2061"}) {
		t.Fatalf("client ports = %v, want only the web port", got)
	}

	// A client with no panel binds nothing that can be named here.
	bare := &config.Config{}
	bare.Client.RemoteAddr = "example.com:3080"
	if got := portsInUse(bare); len(got) != 0 {
		t.Fatalf("a client with no web port reported %v", got)
	}
}

// The bind address of a datagram transport has to be reported as UDP: probing
// it as TCP is what let a reload restart into `address already in use`.
func TestPortsInUseNamesTheTransportsOwnProtocol(t *testing.T) {
	kcp := &config.Config{}
	kcp.Server.BindAddr = "0.0.0.0:3080"
	kcp.Server.Transport = config.KCP
	got := portsInUse(kcp)
	if len(got) != 1 || got[0] != (listenerBinding{network: "udp", address: "0.0.0.0:3080"}) {
		t.Fatalf("kcp ports = %v, want the bind address as UDP", got)
	}

	// A raw-socket transport has no listener to probe, so only the web port
	// is waited for.
	spoof := &config.Config{}
	spoof.Server.BindAddr = "0.0.0.0:3080"
	spoof.Server.Transport = config.SPOOF
	spoof.Server.WebPort = 2060
	got = portsInUse(spoof)
	if len(got) != 1 || got[0] != (listenerBinding{network: "tcp", address: ":2060"}) {
		t.Fatalf("spoof ports = %v, want only the web port", got)
	}
}

func TestTunnelNetwork(t *testing.T) {
	tests := []struct {
		transport config.TransportType
		want      string
	}{
		{config.TCP, "tcp"},
		{config.TCPMUX, "tcp"},
		{config.WS, "tcp"},
		{config.WSS, "tcp"},
		{config.WSMUX, "tcp"},
		{config.WSSMUX, "tcp"},
		{config.STEALTH, "tcp"},
		{config.UDP, "udp"},
		{config.KCP, "udp"},
		{config.QUIC, "udp"},
		{config.XDI, ""},
		{config.SPOOF, ""},
		{config.PCK, ""},
	}
	for _, tt := range tests {
		if got := tunnelNetwork(tt.transport); got != tt.want {
			t.Errorf("tunnelNetwork(%q) = %q, want %q", tt.transport, got, tt.want)
		}
	}
}

// waitForPorts must return once the address is free, and must give up rather
// than hang when it never comes free.
func TestWaitForPorts(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	addr := ln.Addr().String()

	// Held open: this cannot succeed, so it has to give up on the timeout.
	start := time.Now()
	waitForPorts(context.Background(), []listenerBinding{{network: "tcp", address: addr}})
	held := time.Since(start)
	ln.Close()
	if held < portSettleTimeout {
		t.Fatalf("gave up after %v without waiting out the settle timeout", held)
	}

	// Now free: this should return almost immediately.
	start = time.Now()
	waitForPorts(context.Background(), []listenerBinding{{network: "tcp", address: addr}})
	if free := time.Since(start); free > 2*time.Second {
		t.Fatalf("took %v to notice a free port", free)
	}
}

// The bug in one test: a UDP socket is still bound, and the TCP port of the
// same number is free. Probing as TCP returns at once and the reload races the
// socket that is actually still there.
func TestWaitForPortsWaitsOutADatagramSocket(t *testing.T) {
	pc, err := net.ListenPacket("udp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen udp: %v", err)
	}
	addr := pc.LocalAddr().String()

	go func() {
		time.Sleep(300 * time.Millisecond)
		pc.Close()
	}()

	start := time.Now()
	waitForPorts(context.Background(), []listenerBinding{{network: "udp", address: addr}})
	waited := time.Since(start)
	if waited < 250*time.Millisecond {
		t.Fatalf("returned after %v; the UDP socket was still bound", waited)
	}
	if waited > 2*time.Second {
		t.Fatalf("took %v to notice the UDP socket was released", waited)
	}
}

// Every binding gets its own settling budget, so a slow one does not eat the
// wait belonging to the binding after it.
func TestWaitForPortsBudgetsEachBindingSeparately(t *testing.T) {
	held, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	defer held.Close()

	free, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	freeAddr := free.Addr().String()
	free.Close()

	start := time.Now()
	waitForPorts(context.Background(), []listenerBinding{
		{network: "tcp", address: held.Addr().String()},
		{network: "tcp", address: freeAddr},
	})
	// The held one costs the full timeout; the free one must still be checked
	// rather than skipped, so this stays close to a single budget.
	if elapsed := time.Since(start); elapsed > portSettleTimeout+2*time.Second {
		t.Fatalf("two bindings took %v, want roughly one settle timeout", elapsed)
	}
}
