package cmd

import (
	"fmt"
	"net"
	"os"
	"os/exec"
	"runtime"
	"strings"

	"github.com/backpack/backpack/config"
	"github.com/backpack/backpack/internal/app"
	"github.com/backpack/backpack/internal/tunnel/l3"
	"github.com/backpack/backpack/internal/tunnel/naive"
	"github.com/backpack/backpack/internal/utils/network"

	"github.com/sirupsen/logrus"
)

const ( // Default values
	defaultToken          = "backpack"
	defaultChannelSize    = 2048
	defaultRetryInterval  = 3 // only for client
	defaultConnectionPool = 8
	defaultLogLevel       = "info"
	defaultMuxSession     = 1
	defaultKeepAlive      = 75
	defaultHeartbeat      = 40 // 40 seconds

	// defaultDatagramSockBuf is the socket buffer a datagram transport asks
	// for when its config names none. See applyDefaults.
	defaultDatagramSockBuf = 4 << 20
	defaultDialTimeout     = 10 // 10 seconds
	// related to smux
	//
	// There is no default mux version here any more. There was one, pinned at 1
	// with a paragraph explaining why raising it would break every mux tunnel
	// the moment one end was upgraded — and the version is settled on the
	// control channel now instead, so nothing read it. Both the mechanism and
	// that reasoning live in internal/utils/network/mux.go.
	defaultMaxFrameSize     = 32768   // 32KB
	defaultMaxReceiveBuffer = 4194304 // 4MB
	defaultMaxStreamBuffer  = 65536   // 64KB
	defaultSnifferLog       = "backpack.json"
	defaultMuxCon           = 8
)

func applyDefaults(cfg *config.Config) {
	// Socket buffers for the datagram transports, when the file sets none.
	//
	// The wizard's presets always set them (4 to 32 MB); a config written by
	// hand, or by an older build, may not, and then a KCP, xdi, pck, QUIC or UDP
	// tunnel ran on the kernel's default of about 200 KB. Under many
	// simultaneous connections — which is what a VPN carries — that buffer
	// overflows, datagrams are dropped, and the reliability layer spends the
	// CPU retransmitting them. Measured with 16 concurrent streams over KCP:
	// 188 Mbit/s for 21 CPU-seconds on the default buffer, 2,089 Mbit/s for 11
	// on 4 MB. The kernel caps the request at net.core.rmem_max, so asking for
	// more than a machine allows is harmless. TCP is left alone: pinning its
	// buffer turns off the kernel's own tuning, which does better.
	for _, side := range []struct {
		tr       config.TransportType
		rcv, snd *int
	}{
		{cfg.Server.Transport, &cfg.Server.SO_RCVBUF, &cfg.Server.SO_SNDBUF},
		{cfg.Client.Transport, &cfg.Client.SO_RCVBUF, &cfg.Client.SO_SNDBUF},
	} {
		switch side.tr {
		case config.KCP, config.XDI, config.PCK, config.QUIC, config.UDP:
			if *side.rcv <= 0 {
				*side.rcv = defaultDatagramSockBuf
			}
			if *side.snd <= 0 {
				*side.snd = defaultDatagramSockBuf
			}
		}
	}

	// Token. A reverse tunnel written without one falls back to a built-in
	// default, for compatibility with files that have always relied on it —
	// but that default is in the public source, so anyone can claim the control
	// channel of such a tunnel. It is said out loud rather than silently.
	if cfg.Server.Token == "" {
		cfg.Server.Token = defaultToken
		if cfg.Server.BindAddr != "" {
			logger.Warn(defaultTokenWarning)
		}
	}
	if cfg.Client.Token == "" {
		cfg.Client.Token = defaultToken
		if cfg.Client.RemoteAddr != "" {
			logger.Warn(defaultTokenWarning)
		}
	}

	// Nodelay default is false if not valid value found

	// Channel size
	if cfg.Server.ChannelSize <= 0 {
		cfg.Server.ChannelSize = defaultChannelSize
	}

	// Loglevel
	if _, err := logrus.ParseLevel(cfg.Client.LogLevel); err != nil {
		cfg.Client.LogLevel = defaultLogLevel
	}

	if _, err := logrus.ParseLevel(cfg.Server.LogLevel); err != nil {
		cfg.Server.LogLevel = defaultLogLevel
	}

	// Retry interval
	if cfg.Client.RetryInterval <= 0 {
		cfg.Client.RetryInterval = defaultRetryInterval
	}

	// Connection pool
	if cfg.Client.ConnectionPool <= 0 {
		cfg.Client.ConnectionPool = defaultConnectionPool
	}

	// Mux Session
	if cfg.Server.MuxSession <= 0 {
		cfg.Server.MuxSession = defaultMuxSession
	}
	if cfg.Client.MuxSession <= 0 {
		cfg.Client.MuxSession = defaultMuxSession
	}

	// PPROF default is false if not valid value found

	// keep alive
	if cfg.Server.Keepalive <= 0 {
		cfg.Server.Keepalive = defaultKeepAlive
	}
	if cfg.Client.Keepalive <= 0 {
		cfg.Client.Keepalive = defaultKeepAlive
	}

	// Mux version. Left alone when it is 1 or 2 — an explicit choice is still
	// honoured — and otherwise reset to auto, which has the server settle it on
	// the control channel. Anything out of range is a typo, and auto is the
	// safe reading of one.
	if cfg.Server.MuxVersion != 1 && cfg.Server.MuxVersion != 2 {
		cfg.Server.MuxVersion = network.MuxVersionAuto
	}
	if cfg.Client.MuxVersion != 1 && cfg.Client.MuxVersion != 2 {
		cfg.Client.MuxVersion = network.MuxVersionAuto
	}
	// MaxFrameSize
	if cfg.Server.MaxFrameSize <= 0 {
		cfg.Server.MaxFrameSize = defaultMaxFrameSize
	}
	if cfg.Client.MaxFrameSize <= 0 {
		cfg.Client.MaxFrameSize = defaultMaxFrameSize
	}
	// MaxReceiveBuffer
	if cfg.Server.MaxReceiveBuffer <= 0 {
		cfg.Server.MaxReceiveBuffer = defaultMaxReceiveBuffer
	}
	if cfg.Client.MaxReceiveBuffer <= 0 {
		cfg.Client.MaxReceiveBuffer = defaultMaxReceiveBuffer
	}
	// MaxStreamBuffer
	if cfg.Server.MaxStreamBuffer <= 0 {
		cfg.Server.MaxStreamBuffer = defaultMaxStreamBuffer
	}
	if cfg.Client.MaxStreamBuffer <= 0 {
		cfg.Client.MaxStreamBuffer = defaultMaxStreamBuffer
	}
	// WebPort returns 0 if not exists

	// SnifferLog
	if cfg.Server.SnifferLog == "" {
		cfg.Server.SnifferLog = defaultSnifferLog
	}
	if cfg.Client.SnifferLog == "" {
		cfg.Client.SnifferLog = defaultSnifferLog
	}
	// Heartbeat
	if cfg.Server.Heartbeat < 1 { // Minimum accepted interval is 1 second
		cfg.Server.Heartbeat = defaultHeartbeat
	}

	// Timeout
	if cfg.Client.DialTimeout < 1 { // Minimum accepted value is 1 second
		cfg.Client.DialTimeout = defaultDialTimeout
	}

	// Mux concurrancy
	if cfg.Server.MuxCon < 1 {
		cfg.Server.MuxCon = defaultMuxCon
	}

	warnUnusedStreamBuffer(cfg)
	warnIgnoredProxyProtocol(cfg)
}

const defaultTokenWarning = "this tunnel has no token set, so it uses the built-in default one — which is in the public source code, so anybody can claim this tunnel. Set the same long random token on both ends."

// warnIgnoredProxyProtocol says so when proxy_protocol is set on a server
// transport that cannot carry the header. The wizard never offers it there, but
// a hand-written file could, and the key was then accepted and ignored.
func warnIgnoredProxyProtocol(cfg *config.Config) {
	if !cfg.Server.ProxyProtocol || cfg.Server.BindAddr == "" {
		return
	}
	switch cfg.Server.Transport {
	case config.WS, config.WSS, config.UDP:
		logger.Warnf("proxy_protocol has no effect on the %s transport and is ignored: use tcp, tcpmux, stealth, kcp, pck, quic, wsmux or wssmux to pass the client's address to the service", cfg.Server.Transport)
	}
}

// validateConfig reports the first reason a configuration cannot run, or nil.
//
// It is apart from applyDefaults on purpose. The checks used to end in
// logger.Fatalf inside applyDefaults, which the reload watcher also calls — so
// an edit that parsed but was wrong (a proxy URL, a pck flag, a spoof listener
// without its peer) did not leave the running tunnel alone as a parse error
// does: it exited the process, and systemd's restart read the same file and
// exited again. The first load still treats an error as fatal; a reload logs
// it and keeps what is running. See reload.go.
func validateConfig(cfg *config.Config) error {
	for _, check := range []func(*config.Config) error{
		checkNaive,
		checkXray,
		checkOutbound,
		checkXdi,
		checkSpoof,
		checkPck,
		checkFallbackChain,
		// Last: the specific checks above explain a refusal better than the
		// engine's own validation of the same field would.
		checkEngine,
	} {
		if err := check(cfg); err != nil {
			return err
		}
	}
	return nil
}

func checkNaive(cfg *config.Config) error {
	if !cfg.Client.Naive.Enabled() && !cfg.Server.Naive.Enabled() {
		return nil
	}
	if runtime.GOOS != "linux" {
		return fmt.Errorf("the experimental managed Naive integration currently supports Linux only")
	}
	if err := naive.Validate(cfg); err != nil {
		return fmt.Errorf("Naive configuration: %w", err)
	}
	return nil
}

func checkXray(cfg *config.Config) error {
	if !cfg.Client.Xray.Enabled() && !cfg.Server.Xray.Enabled() {
		return nil
	}
	if runtime.GOOS != "linux" {
		return fmt.Errorf("managed Xray transports currently support Linux only")
	}
	if err := naive.ValidateXray(cfg); err != nil {
		return fmt.Errorf("Xray configuration: %w", err)
	}
	return nil
}

// checkFallbackChain refuses a fallback list that cannot work, at load time.
//
// A chain that names a transport this engine does not have would otherwise
// produce a tunnel that quietly skips a candidate — and the whole point of the
// chain is that nobody is watching when it rotates, so a silent skip would only
// be discovered as an outage that never recovered.
func checkFallbackChain(cfg *config.Config) error {
	if err := config.ValidateFallbackTransports(cfg.Server.Transport, cfg.Server.FallbackTransports); err != nil {
		return fmt.Errorf("[server] %v", err)
	}
	if err := config.ValidateFallbackTransports(cfg.Client.Transport, cfg.Client.FallbackTransports); err != nil {
		return fmt.Errorf("[client] %v", err)
	}
	// The two ends walk the same list and never tell each other where they are,
	// so a mismatch is not a protocol error — it is a tunnel that takes longer
	// to meet, or never does. It cannot be checked from one side, so it is said
	// out loud instead.
	if len(cfg.Client.FallbackTransports) > 0 {
		logger.Warnf("transport fallback enabled: %v. The [server] end must carry the "+
			"same list in the same order, or the two ends may not meet.",
			config.FallbackNames(cfg.Client.FallbackTransports))
	}
	return nil
}

// checkPck refuses a pck tunnel that cannot work, and validates the flag cycle
// so a typo is named here rather than silently falling back to the default deep
// inside the carrier.
//
// Everything else about the transport configures itself: the interface, the
// local address and the next hop are read from the routing and neighbour
// tables. What cannot be worked out is whether the process is allowed to open a
// packet socket at all, and that is what this checks.
func checkPck(cfg *config.Config) error {
	// A reverse tunnel naming pck as its transport, or a direct one naming it
	// as its carrier.
	//
	// Only the first was checked. The carrier moved to the layer-3 engine and
	// this gate stayed written in terms of [server] and [client], so every
	// check below — Linux, root, the flag list, the MAC, the interface, the
	// iptables warning — was skipped for exactly the configurations the wizard
	// now produces. A direct tunnel over pck without CAP_NET_RAW failed deep
	// inside the carrier on a socket error, rather than at load with the line
	// that says how to grant it.
	//
	// sni is included because sni is pck: the same packet socket, the same
	// pck_* keys, with a TLS ClientHello put at the front of the flow.
	carrier := l3Carrier(cfg)
	reverse := cfg.Server.Transport == config.PCK || cfg.Client.Transport == config.PCK
	if !reverse && carrier != l3.CarrierPck && carrier != l3.CarrierSNI {
		return nil
	}
	if runtime.GOOS != "linux" {
		return fmt.Errorf("the pck transport is only available on Linux (it needs a packet socket)")
	}
	if os.Geteuid() != 0 {
		return fmt.Errorf("the pck transport needs a packet socket, which requires root or CAP_NET_RAW — run as root, or grant the capability with: setcap cap_net_raw+ep %s", app.BinPath)
	}

	pc := cfg.Server.PckConfig
	switch {
	case !reverse:
		pc = cfg.L3.PckConfig
	case cfg.Client.Transport == config.PCK:
		pc = cfg.Client.PckConfig
	}
	if _, err := network.ParseTCPFlagList(pc.PckFlags); err != nil {
		return fmt.Errorf("invalid pck_flags: %v", err)
	}
	if pc.PckGatewayMAC != "" {
		if _, err := net.ParseMAC(pc.PckGatewayMAC); err != nil {
			return fmt.Errorf("invalid pck_gateway_mac %q: %v", pc.PckGatewayMAC, err)
		}
	}
	if pc.PckInterface != "" {
		if _, err := net.InterfaceByName(pc.PckInterface); err != nil {
			return fmt.Errorf("pck_interface %q does not exist on this machine: %v", pc.PckInterface, err)
		}
	}

	// The kernel answers segments arriving for a port it is not listening on
	// with a RST, and that RST looks to any device in between like the flow
	// ending. The carrier installs a rule to drop them; without iptables it
	// cannot, and the tunnel becomes one that works and then intermittently
	// does not, for no visible reason. That is worth saying out loud.
	if _, err := exec.LookPath("iptables"); err != nil {
		logger.Warn("the pck transport needs the iptables binary to stop the kernel resetting its own flow, and it was not found. The tunnel will run, but expect it to drop under load or after a pause. Install iptables.")
	} else {
		logger.Info("pck: rules dropping the kernel's RSTs and keeping the flow out of conntrack are installed on start and removed on stop.")
	}
	return nil
}

// l3Carrier returns the carrier a direct tunnel is configured to use, in lower
// case, or "" when this configuration is not a direct tunnel at all.
//
// The three carrier checks each asked their own version of this question and
// two of them forgot to, so it is one function now.
func l3Carrier(cfg *config.Config) string {
	if !cfg.L3.Enabled() {
		return ""
	}
	return strings.ToLower(strings.TrimSpace(cfg.L3.Carrier))
}

// checkSpoof settles what a configuration naming the spoof carrier is allowed
// to do, and then says everything an operator needs to hear about the route.
//
// IP spoofing is a direct-tunnel carrier now and nothing else. It used to be a
// reverse transport as well, and that arrangement could not work: a reverse
// tunnel is a control channel plus a pool of connections, each its own session,
// and the forged-source carrier reports every one of them at the same address
// because there is no port in the packets it reads. kcp-go keys its sessions on
// that address, so they collapsed onto one and each new session closed the one
// before it. The tunnel reported itself connected and carried nothing. The
// direct tunnel has one session by construction, which is the shape this
// carrier can actually serve.
//
// So a reverse configuration naming it is refused here, by name, with what to
// build instead — rather than started and left to fail in a way that reads like
// a network fault.
func checkSpoof(cfg *config.Config) error {
	if cfg.Server.Transport == config.SPOOF || cfg.Client.Transport == config.SPOOF {
		return fmt.Errorf("transport = \"spoof\" is no longer a reverse tunnel: IP spoofing is a " +
			"direct-tunnel carrier, and a reverse tunnel over it could never carry traffic " +
			"(every one of its pooled sessions arrives at the same address, so each closed the " +
			"one before it). Build it again as a direct tunnel — `sudo backpack` → Setup Iran / " +
			"Setup Kharej → Direct, and choose Spoof as the carrier — which forwards the same " +
			"ports over the same forged-source packets. See docs/ip-spoofing.md.")
	}

	// Everything below is the direct tunnel's carrier.
	if l3Carrier(cfg) != l3.CarrierSpoof {
		return nil
	}
	listening := strings.EqualFold(strings.TrimSpace(cfg.L3.Mode), "listen")
	// The peer's real address is where forged packets actually arrive from, and
	// so which interface receives them: the listening side is told it, the
	// dialling side derives it from the address it reaches out to.
	peerReal := cfg.L3.SpoofConfig.SpoofPeerIP
	if !listening {
		if host, _, err := net.SplitHostPort(cfg.L3.Addr); err == nil {
			peerReal = host
		}
	}
	return checkSpoofCarrier(cfg.L3.SpoofConfig, listening, peerReal)
}

// checkSpoofCarrier validates the forged-source carrier and reports what the
// host has to be set up for. It is the same advice the reverse transport used
// to print, which was the only place any of it existed — a direct tunnel over
// the same carrier needs every word of it.
func checkSpoofCarrier(sc config.SpoofConfig, listening bool, peerReal string) error {
	if runtime.GOOS != "linux" {
		return fmt.Errorf("the spoof carrier is only available on Linux (it needs a raw IP socket)")
	}
	if os.Geteuid() != 0 {
		return fmt.Errorf("the spoof carrier needs a raw IP socket, which requires root or CAP_NET_RAW — run as root, or grant the capability with: setcap cap_net_raw+ep %s", app.BinPath)
	}
	// Validate both directions' profiles. A direction defaults to
	// spoof_profile, then to udp.
	for _, p := range []string{sc.SpoofProfile, sc.SpoofUplink, sc.SpoofDownlink} {
		if _, err := network.ParseSpoofProfile(p); err != nil {
			return fmt.Errorf("invalid spoof profile: %v", err)
		}
	}
	up, down := network.ResolveSpoofDirections(sc.SpoofProfile, sc.SpoofUplink, sc.SpoofDownlink)
	if up != down {
		logger.Infof("spoof is asymmetric: uplink (client→server) %s, downlink (server→client) %s. Both ends must set the same pair.", up, down)
	}
	// The kernel RSTs a forged TCP segment on the side that RECEIVES tcp, so the
	// iptables rule matters whenever either direction is tcp.
	if up == "tcp" || down == "tcp" {
		if _, err := exec.LookPath("iptables"); err != nil {
			logger.Warn("a tcp spoof direction needs the iptables binary to suppress the kernel's RSTs, and it was not found. The tunnel will run, but those RSTs may disrupt it. Install iptables, or use udp/icmp.")
		} else {
			logger.Info("tcp spoof direction: a targeted iptables rule dropping the kernel's RSTs on the tunnel port is installed on start and removed on stop.")
		}
	}

	// The listening side cannot learn its peer's real address from the forged
	// packets, so it must be told it. The dialling side derives it from the
	// address it was given, so spoof_peer_ip is optional there.
	if listening && net.ParseIP(sc.SpoofPeerIP).To4() == nil {
		return fmt.Errorf("the spoof carrier needs spoof_peer_ip set to the peer's real IPv4 address on the listening side (it cannot be learned from the forged packets)")
	}

	// A typo in any forged source is caught here rather than silently sending
	// nothing.
	for _, ip := range sc.SpoofSrcPool {
		if net.ParseIP(ip).To4() == nil {
			return fmt.Errorf("invalid IPv4 %q in spoof_src_pool", ip)
		}
	}

	// Reverse-path filtering is the most common reason a spoof tunnel comes up
	// but carries nothing: this side receives on ordinary AF_INET sockets, which
	// sit above the kernel's IP input, so a strict rp_filter drops the forged-
	// source packets before they ever reach the tunnel.
	//
	// The value that decides this is not conf.all alone: the kernel uses the
	// MAXIMUM of conf.all and the receiving interface's own setting, so a host
	// with all=0 and eth0=1 filters exactly as if it were strict everywhere.
	// Checking only all — which this used to do — passed that host and left the
	// operator with a silent tunnel and a clean bill of health. So the interface
	// the forged packets arrive on is resolved and folded in.
	rxIface := sc.SpoofInterface
	if rxIface == "" {
		rxIface = network.InterfaceTowardPeer(peerReal)
	}
	if v, where := network.EffectiveRPFilter(rxIface); v == 1 {
		fix := "sysctl -w net.ipv4.conf.all.rp_filter=2"
		if rxIface != "" {
			fix += " ; sysctl -w net.ipv4.conf." + rxIface + ".rp_filter=2"
		}
		logger.Warnf("reverse-path filtering is strict (%s=1): the kernel will DROP incoming forged-source packets before the tunnel sees them. Relax it on this host: %s", where, fix)
	} else {
		logger.Info("spoof needs reverse-path filtering relaxed on the receiving host (rp_filter=2 or 0 on net.ipv4.conf.all and the receiving interface) or the kernel drops the forged-source packets.")
	}

	// For icmp, the host kernel would auto-answer each incoming echo request with
	// a reply to the forged source — one full-sized packet out for every one in,
	// on the download path. The carrier drops exactly those with a targeted
	// iptables rule (matched on the tunnel's ICMP identifier), so no operator
	// action is needed and — unlike the old global switch — ICMP arriving on the
	// tunnel itself is untouched. Noted only so the behaviour is not a surprise.
	if up == "icmp" || down == "icmp" {
		if _, err := exec.LookPath("iptables"); err != nil {
			logger.Warn("spoof_profile icmp: iptables was not found, so the kernel's automatic replies to the forged echo requests cannot be dropped. The tunnel still works; it just wastes some uplink answering pings it never sent. Install iptables to silence them.")
		} else {
			logger.Info("spoof_profile icmp: the kernel's automatic replies to the carrier's echo requests are dropped by a targeted iptables rule while the tunnel runs; ICMP on the tunnel itself is unaffected.")
		}
	}
	// The icmpv6 profile carries ICMPv6 echo messages (type 128) inside IPv4
	// packets with protocol 58 — useful where a firewall clamps down on ICMP and
	// UDP but leaves proto 58 open. The kernel does not answer proto-58-in-IPv4,
	// so it needs no reply suppression.
	if up == "icmpv6" || down == "icmpv6" {
		logger.Info("spoof_profile icmpv6: ICMPv6 echo (type 128) inside IPv4 proto 58, a path some firewalls leave more open than icmp/udp. Both ends must set the same profile.")
	}
	// ipip/gre carry no port or identifier, so the receiver cannot filter the
	// flow in the kernel and leans on the source-IP pin. Recommend it.
	if (up == "ipip" || down == "ipip" || up == "gre" || down == "gre") && net.ParseIP(sc.SpoofPeerSrcIP).To4() == nil {
		logger.Info("spoof_profile ipip/gre has no port to demultiplex on: set spoof_peer_src_ip to the peer's forged source so foreign packets of the same protocol are dropped before the encryption; without it every proto-4/47 packet reaches the cipher.")
	}

	logger.Warn("spoof is experimental: it forges the source address of raw IP packets. It only carries traffic where the upstream network does not drop forged-source packets (no egress/BCP38 filtering) — prove this with the spoof tester on your real route before relying on it.")
	return nil
}

// checkXdi refuses an xdi tunnel that cannot possibly work, before it tries.
//
// The transport needs a raw ICMP socket, which needs root or CAP_NET_RAW.
// Without it the socket open fails deep inside the transport with an errno an
// operator should not have to decode; caught here, it names the cause and what
// to do. The server is normally root anyway — this is for the case where it is
// not.
func checkXdi(cfg *config.Config) error {
	// The carrier as well as the transport — see checkPck for why this gate was
	// blind to every configuration the wizard writes.
	usesXdi := cfg.Server.Transport == config.XDI ||
		cfg.Client.Transport == config.XDI ||
		l3Carrier(cfg) == l3.CarrierXdi
	if !usesXdi {
		return nil
	}
	if runtime.GOOS != "linux" {
		return fmt.Errorf("the xdi transport is only available on Linux (it needs a raw ICMP socket)")
	}
	if os.Geteuid() != 0 {
		return fmt.Errorf("the xdi transport needs a raw ICMP socket, which requires root or CAP_NET_RAW — run as root, or grant the capability with: setcap cap_net_raw+ep %s", app.BinPath)
	}
	logger.Warn("xdi is experimental: it carries the tunnel inside ICMP echo (ping) packets, for networks that filter UDP and TCP but not ICMP. It is slower than the other transports and heavier on ICMP rate limits.")
	return nil
}

// checkOutbound rejects a proxy or a routing binding that cannot work, at load
// time.
//
// A misspelled scheme, a missing port or an interface that does not exist would
// otherwise surface as a tunnel that simply never connects, with the reason
// buried in a dial error. Failing here says which line of the file is wrong,
// before anything has started.
func checkOutbound(cfg *config.Config) error {
	proxy, err := network.ParseProxy(cfg.Client.Proxy)
	if err != nil {
		return fmt.Errorf("invalid proxy setting: %v", err)
	}
	out := &network.Outbound{
		Proxy:     proxy,
		LocalAddr: cfg.Client.LocalAddr,
		Interface: cfg.Client.Interface,
		Mark:      cfg.Client.SOMark,
	}
	if !out.IsSet() {
		return nil
	}
	if err := out.Validate(); err != nil {
		return fmt.Errorf("invalid outbound setting: %v", err)
	}

	// The datagram transports carry their data outside the TCP dialer entirely,
	// so none of this would reach it. Half-applying would be worse than
	// refusing: on udp the control channel is TCP and would honour every one of
	// these settings, while the data went out by whatever route the kernel
	// chose. The tunnel would come up and quietly leave by the wrong link — or,
	// with a proxy, come up and carry nothing at all. On kcp, xdi, pck and quic
	// not even the control channel is TCP, so the settings would be accepted and
	// then ignored outright.
	//
	// pck was missing from this list for as long as it existed. It shares its
	// case in client.go with kcp and xdi and, like them, carries everything
	// through a packet socket that KcpConfig has no Outbound field to reach —
	// so a pck tunnel passed this check, was told "the tunnel server will be
	// reached ..." in its own log, and then dialled by whatever route the
	// kernel chose. That is the exact failure the function exists to prevent.
	if transportIgnoresOutbound(cfg.Client.Transport) {
		return fmt.Errorf("proxy, local_addr, interface and so_mark are not supported on the %s transport: its data is not carried over the TCP dialer these settings apply to. Use tcp, tcpmux, ws, wss or wsmux, or remove them.", cfg.Client.Transport)
	}

	logger.Infof("the tunnel server will be reached %s", out)
	return nil
}

// transportIgnoresOutbound reports whether a transport carries its data outside
// the TCP dialer that proxy, local_addr, interface and so_mark apply to.
//
// A function rather than a switch inside checkOutbound so the list can be
// asserted: the check itself ends in logger.Fatalf, which a test cannot call,
// and the only defect this has ever had was a transport missing from the list.
func transportIgnoresOutbound(t config.TransportType) bool {
	switch t {
	case config.UDP, config.KCP, config.XDI, config.PCK, config.QUIC, config.SPOOF:
		return true
	}
	return false
}

// warnUnusedStreamBuffer says out loud that mux_streambuffer does nothing on
// mux version 1.
//
// smux only applies a per-stream receive window in version 2 — in version 1
// there is no per-stream flow control at all, only the session-wide
// mux_receivebuffer. So an operator who pins mux_version to 1 and then sets
// mux_streambuffer to tune a slow tunnel changes nothing whatsoever, and has no
// way to find that out: the setting is accepted, reported back by the panel,
// and silently ignored by the library. Tuning that appears to work and does not
// is worse than tuning that is refused.
//
// Only a pinned 1 is worth warning about. On auto the version is settled with
// the server, and the answer is 2 whenever both ends are new enough to be
// asked — so the setting will be applied unless the peer is too old, which is
// reported on the control channel instead.
const unusedStreamBufferWarning = "mux_streambuffer has no effect while mux_version is pinned to 1: smux only applies a per-stream window on version 2. Remove mux_version to let the two ends agree on it, or set it to 2 on both."

func warnUnusedStreamBuffer(cfg *config.Config) {
	if cfg.Server.MaxStreamBuffer > 0 && cfg.Server.MuxVersion == 1 && cfg.Server.BindAddr != "" {
		logger.Warn(unusedStreamBufferWarning)
	}
	if cfg.Client.MaxStreamBuffer > 0 && cfg.Client.MuxVersion == 1 && cfg.Client.RemoteAddr != "" {
		logger.Warn(unusedStreamBufferWarning)
	}
}
